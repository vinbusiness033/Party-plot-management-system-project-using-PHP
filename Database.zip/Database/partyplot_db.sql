-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2025 at 05:30 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `partyplot_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `created_at`) VALUES
(11, 'vinayak', '4ab08e00416202964573321aad392d9f', '2025-09-13 06:09:51'),
(13, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2025-09-17 15:01:11');

-- --------------------------------------------------------

--
-- Table structure for table `availability`
--

CREATE TABLE `availability` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blocked_dates`
--

CREATE TABLE `blocked_dates` (
  `id` int(11) NOT NULL,
  `blocked_date` date NOT NULL,
  `reason` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blocked_dates`
--

INSERT INTO `blocked_dates` (`id`, `blocked_date`, `reason`) VALUES
(3, '2026-01-06', 'birthday'),
(4, '2026-02-18', 'personal date');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `function_type` varchar(100) NOT NULL,
  `venue` varchar(200) NOT NULL,
  `decoration_option` enum('With Decoration','Without Decoration') NOT NULL,
  `guests` int(11) DEFAULT NULL,
  `special_requirements` text DEFAULT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('Pending','Confirmed','Cancelled','Completed','Paid') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `client_name`, `phone`, `email`, `function_type`, `venue`, `decoration_option`, `guests`, `special_requirements`, `total_price`, `status`, `created_at`) VALUES
(56, 'vinayak parmar', '+91 9824751013', 'parmarvinayak@gmail.com', 'Wedding', 'Ground', 'Without Decoration', 1100, '', 170000.00, 'Cancelled', '2025-09-19 16:00:26'),
(57, 'Haridas patel', '+91 9710568461', 'hari@gml.com', 'Corporate', 'Ground', 'With Decoration', 2000, 'chairs for katha', 240000.00, 'Paid', '2025-09-19 16:03:20'),
(58, 'Nehal patel', '+91 9223656898', 'nehal@gml.com', 'Haldi', 'Ground', 'Without Decoration', 550, 'yellow theme', 170000.00, 'Pending', '2025-09-19 16:04:33'),
(59, 'Ashokbhai Makwana', '+91 9759980123', 'ask@mail.com', 'Religious/Social Events (Katha, Satsang, Bhajan, Music Sandhya, Get-together)', 'Dome', 'Without Decoration', 950, 'required Stage for Bhajan', 200000.00, 'Paid', '2025-10-06 05:23:22'),
(60, 'dev mori', '+91 9824654012', 'dev@gmai.com', 'Wedding', 'Ground+Dome+Rooms', 'With Decoration', 1500, '', 500000.00, 'Paid', '2025-10-12 18:11:26'),
(61, 'hitesh patel', '+91 6890124545', 'hitesh@gmail.com', 'Wedding', 'Ground+Dome+Rooms', 'With Decoration', 1600, 'drone flower rain, sofas, welcome drink', 500000.00, 'Paid', '2025-10-31 16:17:23'),
(62, 'moksha parmar', '+91 9825451015', 'moksha@gmail.com', 'Birthday', 'Dome', 'Without Decoration', 600, '', 200000.00, 'Paid', '2025-10-31 16:21:06');

-- --------------------------------------------------------

--
-- Table structure for table `booking_dates`
--

CREATE TABLE `booking_dates` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `event_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_dates`
--

INSERT INTO `booking_dates` (`id`, `booking_id`, `event_date`) VALUES
(1, 56, '2025-10-14'),
(2, 56, '2025-10-15'),
(3, 57, '2025-11-12'),
(4, 57, '2025-11-13'),
(5, 57, '2025-11-14'),
(6, 58, '2025-10-04'),
(7, 59, '2025-11-18'),
(8, 59, '2025-11-19'),
(9, 60, '2025-10-28'),
(10, 60, '2025-10-29'),
(11, 61, '2025-12-17'),
(12, 61, '2025-12-18'),
(13, 61, '2025-12-19'),
(14, 62, '2025-11-24');

-- --------------------------------------------------------

--
-- Table structure for table `contact_info`
--

CREATE TABLE `contact_info` (
  `id` int(11) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_info`
--

INSERT INTO `contact_info` (`id`, `phone`, `email`, `address`) VALUES
(1, '+91 9824659013', 'aagmanbanquet@gmail.com', 'Aagman party plot, Sandipani crossroad, Halvad, Gujarat, India');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `submitted_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `phone`, `subject`, `message`, `submitted_at`) VALUES
(1, 'vinayak ', 'parmarvinayak@gmail.com', '+91 9859784510', 'regarding cancelation', 'i want to cancel my function', '2025-09-19 21:49:29');

-- --------------------------------------------------------

--
-- Table structure for table `decoration_prices`
--

CREATE TABLE `decoration_prices` (
  `id` int(11) NOT NULL,
  `function_type` varchar(200) NOT NULL,
  `approx_price` decimal(10,2) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `decoration_prices`
--

INSERT INTO `decoration_prices` (`id`, `function_type`, `approx_price`, `updated_at`) VALUES
(1, 'Wedding', 100000.00, '2025-09-17 15:36:21'),
(4, 'Engagement', 100000.00, '2025-09-17 15:36:21'),
(6, 'Birthday', 50000.00, '2025-09-17 17:04:06'),
(7, 'Haldi', 50000.00, '2025-09-19 12:03:28'),
(8, 'Baby Shower', 60000.00, '2025-09-19 12:04:43'),
(9, 'Corporate (Meetings, Seminars, Business Meetings)', 60000.00, '2025-09-24 04:33:59'),
(11, 'Religious/Social Events (Katha, Satsang, Bhajan, Music Sandhya, Get-together)', 70000.00, '2025-09-24 04:45:03');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `client_email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `submitted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `quiz1` varchar(50) DEFAULT NULL,
  `quiz2` varchar(50) DEFAULT NULL,
  `quiz3` varchar(50) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `client_name`, `client_email`, `message`, `submitted_at`, `quiz1`, `quiz2`, `quiz3`, `rating`) VALUES
(1, 'vinayak parmar', 'parmar@gmil.com', 'excellent partyplot', '2025-10-14 10:37:43', 'Very Satisfied', 'Excellent', 'Definitely', 5),
(2, 'Raj patel', 'raj@gmail.com', '', '2025-10-31 21:52:01', 'Very Satisfied', 'Excellent', 'Definitely', 5),
(3, 'moksha', 'mok@gmail.com', 'Add more photoshoot themes', '2025-10-31 21:53:49', 'Very Satisfied', 'Good', 'Maybe', 4);

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `function_type` varchar(100) NOT NULL,
  `media_type` enum('image','video') NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(20) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_highlight` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `function_type`, `media_type`, `file_name`, `file_type`, `uploaded_at`, `is_highlight`) VALUES
(12, 'Wedding', 'image', '1757436636_wed3.jpeg', 'jpeg', '2025-09-09 16:50:36', 0),
(13, 'Birthday', 'image', '1757436653_bd.jpeg', 'jpeg', '2025-09-09 16:50:53', 0),
(14, 'Birthday', 'image', '1757436653_bd2.jpeg', 'jpeg', '2025-09-09 16:50:53', 0),
(15, 'Birthday', 'image', '1757436653_bd3.jpeg', 'jpeg', '2025-09-09 16:50:53', 0),
(16, 'Rooms', 'image', '1757436678_room.jpeg', 'jpeg', '2025-09-09 16:51:18', 0),
(17, 'Rooms', 'image', '1757436678_room2.jpeg', 'jpeg', '2025-09-09 16:51:19', 0),
(20, 'Other', 'image', '1757436717_theme.jpg', 'jpg', '2025-09-09 16:51:57', 0),
(21, 'Other', 'image', '1757436717_theme2.jpeg', 'jpeg', '2025-09-09 16:51:57', 0),
(22, 'Other', 'image', '1757436717_theme3.jpeg', 'jpeg', '2025-09-09 16:51:57', 0),
(24, 'Other', 'image', '1757436717_theme5.jpeg', 'jpeg', '2025-09-09 16:51:57', 0),
(29, 'Other', 'video', '1757573781_WhatsApp Video 2025-09-09 at 10.45.15 PM.mp4', 'mp4', '2025-09-11 06:56:21', 1),
(30, 'Other', 'video', '1757573781_WhatsApp Video 2025-09-09 at 10.41.56 PM.mp4', 'mp4', '2025-09-11 06:56:21', 0),
(38, 'Other', 'image', '1757576523_C1QyLxnokSv(HEIC).heic', 'heic', '2025-09-11 07:42:03', 1),
(40, 'Other', 'image', '1757576523_C1QyRB7IozT(HEIC).heic', 'heic', '2025-09-11 07:42:03', 1),
(47, 'Birthday', 'image', '1757577653_Birthday party 2.heic', 'heic', '2025-09-11 08:00:53', 0),
(48, 'Birthday', 'image', '1757577653_Birthday party 3.heic', 'heic', '2025-09-11 08:00:53', 0),
(50, 'Birthday', 'image', '1757577653_Birthday party 1.heic', 'heic', '2025-09-11 08:00:53', 0),
(52, 'Photoshoot', 'image', '1757705642_01.jpg', 'jpg', '2025-09-12 19:34:02', 0),
(53, 'Photoshoot', 'image', '1757705699_02.jpg', 'jpg', '2025-09-12 19:34:59', 1),
(54, 'Rooms', 'image', '1757705890_04.jpg', 'jpg', '2025-09-12 19:38:10', 0),
(55, 'Rooms', 'image', '1757705890_03.jpg', 'jpg', '2025-09-12 19:38:10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `inquiries`
--

CREATE TABLE `inquiries` (
  `inquiry_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `package_details`
--

CREATE TABLE `package_details` (
  `id` int(11) NOT NULL,
  `facilities` text DEFAULT NULL,
  `guest_capacity` varchar(100) DEFAULT NULL,
  `duration` varchar(50) DEFAULT NULL,
  `services` text DEFAULT NULL,
  `policies` text DEFAULT NULL,
  `cancellation_policy` text DEFAULT NULL,
  `other_details` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `package_details`
--

INSERT INTO `package_details` (`id`, `facilities`, `guest_capacity`, `duration`, `services`, `policies`, `cancellation_policy`, `other_details`, `updated_at`) VALUES
(1, 'Large-Parking\r\nDecoration \r\nAC-Rooms(30)\r\nAC-Domes(2)\r\nLawn-Ground(1)', '2500', 'Full Day', 'Lighting \r\nPower Backup Generator included\r\nSecurity\r\nFull Lighting Setup (Stage + Lawn + Entry Gate)\r\nSpecial Decoration\r\nThemes Customization\r\nSofas and Chairs Available\r\nOwn Stage Tables', 'No Alcohol Allowed\r\nNo Crackers Allowed\r\nWe will schedule your function dates after receiving your payment', 'Cancellations made at least 30 days before the event are eligible for a half refund', 'Contact office for more Information', '2025-09-24 04:23:43');

-- --------------------------------------------------------

--
-- Table structure for table `photoshoots`
--

CREATE TABLE `photoshoots` (
  `ps_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `persons` int(11) NOT NULL,
  `date` date NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `payment_status` enum('unpaid','paid') DEFAULT 'unpaid',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `photoshoots`
--

INSERT INTO `photoshoots` (`ps_id`, `name`, `email`, `phone`, `user_id`, `persons`, `date`, `total_price`, `payment_status`, `created_at`) VALUES
(11, 'kishan vadsola', 'kishan@gml.com', '+91 9875465012', NULL, 6, '2025-10-01', 3000.00, 'paid', '2025-09-19 15:01:34'),
(12, 'bhuvnesh jangid', 'bhuvni@gml.com', '+91 9865012356', NULL, 8, '2025-10-16', 4000.00, 'paid', '2025-09-19 15:06:12'),
(13, 'maheshbhai parmar', 'mahesh@mail.com', '+91 9763287412', NULL, 8, '2025-10-23', 2500.00, 'paid', '2025-09-24 03:54:46'),
(14, 'janvi parmar', 'janvi@gmail.com', '+91 8978455623', NULL, 10, '2025-10-22', 3500.00, 'paid', '2025-09-26 07:56:58'),
(15, 'Mehul sathwara', 'mehul@gmail.com', '+91 9568784598', NULL, 8, '2025-11-23', 2500.00, 'paid', '2025-10-06 05:18:36'),
(16, 'Niki', 'niki@gmail.com', '+91 8200654051', NULL, 1, '2025-10-07', 2500.00, 'unpaid', '2025-10-08 08:02:39'),
(17, 'Niki', 'niki@gmail.com', '+91 8200654051', NULL, 1, '2025-10-07', 2500.00, 'unpaid', '2025-10-08 08:03:27'),
(18, 'ajay parmar', 'aj@gmail.com', '+91 9856235478', NULL, 10, '2025-10-23', 3500.00, 'paid', '2025-10-12 18:09:09'),
(19, 'parmar vishal', 'vishal@gmail.com', '+91 9878562302', NULL, 10, '2025-11-07', 3100.00, 'paid', '2025-10-31 16:13:24'),
(20, 'chintan vyas', 'vvyas@gmail.com', '+91 8978450123', NULL, 8, '2025-12-24', 2500.00, 'paid', '2025-10-31 16:14:41');

-- --------------------------------------------------------

--
-- Table structure for table `photoshoot_settings`
--

CREATE TABLE `photoshoot_settings` (
  `id` int(11) NOT NULL,
  `base_price` int(11) NOT NULL,
  `extra_person_price` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `included_persons` int(11) NOT NULL DEFAULT 6
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `photoshoot_settings`
--

INSERT INTO `photoshoot_settings` (`id`, `base_price`, `extra_person_price`, `updated_at`, `included_persons`) VALUES
(1, 3000, 500, '2025-09-07 05:24:39', 6),
(2, 2500, 500, '2025-09-07 06:10:24', 6),
(3, 3000, 500, '2025-09-07 07:05:45', 4),
(4, 3000, 500, '2025-09-07 07:09:50', 6),
(5, 2500, 500, '2025-09-24 03:52:44', 8),
(6, 2500, 300, '2025-10-12 18:12:29', 8);

-- --------------------------------------------------------

--
-- Table structure for table `refunds`
--

CREATE TABLE `refunds` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `client_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `refund_status` enum('Pending','Processed','Rejected') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `refunds`
--

INSERT INTO `refunds` (`id`, `booking_id`, `client_name`, `phone`, `email`, `amount`, `refund_status`, `created_at`) VALUES
(2, 56, 'vinayak parmar', '+91 9824751013', 'parmarvinayak@gmail.com', 170000, 'Pending', '2025-09-19 16:07:16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer') DEFAULT 'customer',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'admin', 'admin@partyplot.com', '0192023a7bbd73250516f069df18b500', 'admin', '2025-09-05 13:56:08');

-- --------------------------------------------------------

--
-- Table structure for table `venue_prices`
--

CREATE TABLE `venue_prices` (
  `id` int(11) NOT NULL,
  `ground_price` decimal(10,2) NOT NULL,
  `dome_price` decimal(10,2) NOT NULL,
  `room_price` decimal(10,2) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `venue_prices`
--

INSERT INTO `venue_prices` (`id`, `ground_price`, `dome_price`, `room_price`, `updated_at`) VALUES
(1, 50000.00, 30000.00, 20000.00, '2025-09-12 15:41:33'),
(2, 150000.00, 200000.00, 30000.00, '2025-09-17 15:25:32'),
(3, 170000.00, 200000.00, 30000.00, '2025-09-17 15:36:21'),
(4, 170000.00, 200000.00, 30000.00, '2025-09-17 17:04:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `availability`
--
ALTER TABLE `availability`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blocked_dates`
--
ALTER TABLE `blocked_dates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `blocked_date` (`blocked_date`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_dates`
--
ALTER TABLE `booking_dates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `contact_info`
--
ALTER TABLE `contact_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `decoration_prices`
--
ALTER TABLE `decoration_prices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inquiries`
--
ALTER TABLE `inquiries`
  ADD PRIMARY KEY (`inquiry_id`);

--
-- Indexes for table `package_details`
--
ALTER TABLE `package_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `photoshoots`
--
ALTER TABLE `photoshoots`
  ADD PRIMARY KEY (`ps_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `photoshoot_settings`
--
ALTER TABLE `photoshoot_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `refunds`
--
ALTER TABLE `refunds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `venue_prices`
--
ALTER TABLE `venue_prices`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `availability`
--
ALTER TABLE `availability`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blocked_dates`
--
ALTER TABLE `blocked_dates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `booking_dates`
--
ALTER TABLE `booking_dates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `contact_info`
--
ALTER TABLE `contact_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `decoration_prices`
--
ALTER TABLE `decoration_prices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `inquiries`
--
ALTER TABLE `inquiries`
  MODIFY `inquiry_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `package_details`
--
ALTER TABLE `package_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `photoshoots`
--
ALTER TABLE `photoshoots`
  MODIFY `ps_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `photoshoot_settings`
--
ALTER TABLE `photoshoot_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `refunds`
--
ALTER TABLE `refunds`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `venue_prices`
--
ALTER TABLE `venue_prices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking_dates`
--
ALTER TABLE `booking_dates`
  ADD CONSTRAINT `booking_dates_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `photoshoots`
--
ALTER TABLE `photoshoots`
  ADD CONSTRAINT `photoshoots_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `refunds`
--
ALTER TABLE `refunds`
  ADD CONSTRAINT `refunds_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
