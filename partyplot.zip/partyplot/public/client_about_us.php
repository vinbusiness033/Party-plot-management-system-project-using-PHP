<?php
include("../config/db.php");

// Get contact details (id=1)
$sql = "SELECT * FROM contact_info WHERE id = 1";
$result = $conn->query($sql);
$contact = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Contact Us</title>
    <style>
        body { font-family: Arial, sans-serif; background: #c6953F; color: #4b0000; padding: 20px; }
        .container { max-width: 600px; margin:auto; background:#4b0000; color:white; padding: 20px; border-radius: 8px; }
        h2 { color:#c6953F; }
        .info { margin-top: 15px; }
        .label { font-weight: bold; color: #c6953F; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Contact Us</h2>
        <div class="info">
            <p><span class="label">Phone:</span> <?php echo htmlspecialchars($contact['phone']); ?></p>
            <p><span class="label">Email:</span> <?php echo htmlspecialchars($contact['email']); ?></p>
            <p><span class="label">Address:</span><br><?php echo nl2br(htmlspecialchars($contact['address'])); ?></p>
        </div>
        <a href="index.php" class="back-link">⬅ Back</a>

    </div>
</body>
</html>
