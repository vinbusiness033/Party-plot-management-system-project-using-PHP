<?php
include("../config/db.php");

$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $subject = $conn->real_escape_string($_POST['subject']);
    $message_text = $conn->real_escape_string($_POST['message']);

    $sql = "INSERT INTO contact_messages (name, email, phone, subject, message, submitted_at) 
            VALUES ('$name', '$email', '$phone', '$subject', '$message_text', NOW())";

    if ($conn->query($sql) === TRUE) {
        $message = "Your message has been sent successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Contact Us</title>
    <style>
        /* Basic styling */
        body { font-family: Arial, sans-serif; background: #c6953F; color: #4b0000; }
        .container { max-width:600px; margin:auto; background:#4b0000; padding:20px; border-radius:8px; color:white; }
        label { color: #c6953F; font-weight:bold; }
        input, textarea { width: 100%; padding: 10px; margin: 6px 0 12px 0; border-radius: 4px; border: 1px solid #c6953F; background: #1c1c1c; color: white; }
        input[type=submit] { background: #300B1C; color: #f9f1f1; border: none; cursor: pointer; font-weight: bold; }
        input[type=submit]:hover { background: #4b0000; }
        .message { text-align:center; margin-bottom: 15px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Contact Us</h2>
        <?php if($message != ""): ?>
          <p class="message"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>
        <form method="POST" action="">
            <label for="name">Name:</label>
            <input required type="text" id="name" name="name" placeholder="Your name" />

            <label for="email">Email:</label>
            <input required type="email" id="email" name="email" placeholder="Your email" />

            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" placeholder="+91 9999999999" pattern="\+91\s\d{10}" title="Enter valid phone number" />

            <label for="subject">Subject:</label>
            <input required type="text" id="subject" name="subject" placeholder="Subject" />

            <label for="message">Message:</label>
            <textarea required rows="5" id="message" name="message" placeholder="Write your message here..."></textarea>

            <input type="submit" value="Send Message" />
        </form>
        <a href="index.php" class="back-link">⬅ Back</a>

    </div>
</body>
</html>
