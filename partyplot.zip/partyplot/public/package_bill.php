<?php
include("../config/db.php");

$booking_id = isset($_GET['booking_id']) ? intval($_GET['booking_id']) : 0;
if (!$booking_id) {
    die("Invalid booking ID.");
}

$error = '';
$success = '';

// Fetch main booking info
$stmt = $conn->prepare("SELECT * FROM bookings WHERE id = ?");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    die("Booking not found.");
}
$booking = $result->fetch_assoc();
$stmt->close();

$decoration_display = $booking['decoration_option'] ?? 'Unknown';

// Fetch all booked dates
$stmt = $conn->prepare("SELECT event_date FROM booking_dates WHERE booking_id = ?");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$date_result = $stmt->get_result();
$dates_arr = [];
while ($row = $date_result->fetch_assoc()) {
    $dates_arr[] = $row['event_date'];
}
$stmt->close();

$dates_display = empty($dates_arr) ? 'No dates selected' : implode(', ', $dates_arr);

// Update status to Paid on payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $booking['status'] !== 'Paid') {
    $update_stmt = $conn->prepare("UPDATE bookings SET status = 'Paid' WHERE id = ?");
    $update_stmt->bind_param("i", $booking_id);
    if ($update_stmt->execute()) {
        $success = "Payment successful! Booking status updated to Paid.";
        $booking['status'] = 'Paid'; // Update in memory for UI
    } else {
        $error = "Payment failed. Please try again.";
    }
    $update_stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Booking Bill & Payment</title>
<style>
    body { font-family: Arial, sans-serif; margin: 20px; background: #f9f9f9; }
    .container { max-width: 700px; background: white; margin: auto; padding: 25px; border-radius: 8px; border: 1px solid #ccc; }
    h1 { color: #4b0000; text-align: center; }
    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
    th, td { border: 1px solid #ddd; padding: 12px; }
    th { background: #c6953f; color: #300b1c; }
    .status-paid { color: green; font-weight: bold; }
    .status-pending { color: orange; font-weight: bold; }
    .error { background: #ffd4d4; color: #b00000; padding: 12px; border-radius: 6px; margin-bottom: 15px; }
    .success { background: #d4ffd4; color: green; padding: 12px; border-radius: 6px; margin-bottom: 15px; }
    .btn-pay { background: #c6953f; color: #300b1c; border: none; padding: 12px 24px; cursor: pointer; font-weight: bold; border-radius: 6px; }
    .btn-pay:hover { background: gold; }
    .print-button { margin-top: 15px; }
</style>
<script>
function printBill() {
    window.print();
}
</script>
</head>
<body>
<div class="container">
<h1>Booking Bill & Payment</h1>
<?php if ($error): ?>
<div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
<div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<table>
<tr><th>Field</th><th>Details</th></tr>
<tr><td>Client Name</td><td><?= htmlspecialchars($booking['client_name']) ?></td></tr>
<tr><td>Phone</td><td><?= htmlspecialchars($booking['phone']) ?></td></tr>
<tr><td>Email</td><td><?= htmlspecialchars($booking['email']) ?></td></tr>
<tr><td>Function</td><td><?= htmlspecialchars($booking['function_type']) ?></td></tr>
<tr><td>Venue</td><td><?= htmlspecialchars($booking['venue']) ?></td></tr>
<tr><td>Decoration Option</td><td><?= htmlspecialchars($decoration_display) ?></td></tr>
<tr><td>Event Dates</td><td><?= htmlspecialchars($dates_display) ?></td></tr>
<tr><td>Number of Guests</td><td><?= htmlspecialchars($booking['guests']) ?></td></tr>
<tr><td>Special Requirements</td><td><?= nl2br(htmlspecialchars($booking['special_requirements'])) ?></td></tr>
<tr><td>Total Price (₹)</td><td><?= number_format($booking['total_price'], 2) ?></td></tr>
<tr><td>Status</td><td class="<?= ($booking['status'] == 'Paid') ? 'status-paid' : 'status-pending' ?>"><?= htmlspecialchars($booking['status']) ?></td></tr>
</table>

<?php if ($booking['status'] !== 'Paid'): ?>
<form method="post" action="">
<button type="submit" class="btn-pay">Pay Now</button>
<a href="booking.php" class="back-link">⬅ Back</a>

</form>
<?php else: ?>
<button onclick="printBill()" class="print-button">Print Bill</button>
 <a href="index.php" class="action-btn home-btn">⬅️ Return to Homepage</a>
<?php endif; ?>
</div>
</body>
</html>
