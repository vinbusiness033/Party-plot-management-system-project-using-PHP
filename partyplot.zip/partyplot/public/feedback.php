<?php
include("../config/db.php");

$message = "";
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $client_name = $conn->real_escape_string($_POST['client_name']);
    $client_email = $conn->real_escape_string($_POST['client_email']);
    $quiz1 = $conn->real_escape_string($_POST['quiz1']);
    $quiz2 = $conn->real_escape_string($_POST['quiz2']);
    $quiz3 = $conn->real_escape_string($_POST['quiz3']);
    $rating = intval($_POST['rating']);
    $feedback_message = $conn->real_escape_string($_POST['message']);

    $sql = "INSERT INTO feedback (client_name, client_email, quiz1, quiz2, quiz3, rating, message)
            VALUES ('$client_name','$client_email','$quiz1','$quiz2','$quiz3',$rating,'$feedback_message')";

    if ($conn->query($sql) === TRUE) {
        $message = "Thank you for sharing your feedback!";
    } else {
        $message = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Give Feedback</title>
    <style>
        body { font-family: Arial, sans-serif; background: #c6953F; color: #4b0000; }
        .container { max-width:600px; margin:auto; background:#4b0000; color:white; padding:24px; border-radius:10px; }
        label { color: #c6953F; font-weight: bold; margin-top:15px;}
        input, textarea, select { width:100%; padding:8px; margin:8px 0; border-radius:6px; border:1px solid #c6953F; background:#1c1c1c; color:white; }
        input[type=submit] { background:#300B1C; color:#f9f1f1; border:none; cursor:pointer; font-weight:bold; }
        input[type=submit]:hover { background: #4b0000; }
        .option-group { margin-bottom:12px; }
        .rating-group { display:flex; gap:8px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Share Your Feedback</h2>
        <?php if($message!=""): ?>
            <p><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>
        <form method="POST">
            <label for="client_name">Name:</label>
            <input type="text" name="client_name" id="client_name" required />

            <label for="client_email">Email:</label>
            <input type="email" name="client_email" id="client_email" required />

            <div class="option-group">
                <label>How satisfied were you with our booking process?</label>
                <input type="radio" name="quiz1" value="Very Satisfied" required> Very Satisfied
                <input type="radio" name="quiz1" value="Satisfied"> Satisfied
                <input type="radio" name="quiz1" value="Neutral"> Neutral
                <input type="radio" name="quiz1" value="Dissatisfied"> Dissatisfied
                <input type="radio" name="quiz1" value="Very Dissatisfied"> Very Dissatisfied
            </div>

            <div class="option-group">
                <label>How satisfied were you with the gallery?</label>
                <input type="radio" name="quiz2" value="Excellent" required> Excellent
                <input type="radio" name="quiz2" value="Good"> Good
                <input type="radio" name="quiz2" value="Average"> Average
                <input type="radio" name="quiz2" value="Poor"> Poor
            </div>

            <div class="option-group">
                <label>Would you recommend us to others?</label>
                <input type="radio" name="quiz3" value="Definitely" required> Definitely
                <input type="radio" name="quiz3" value="Maybe"> Maybe
                <input type="radio" name="quiz3" value="Not Sure"> Not Sure
                <input type="radio" name="quiz3" value="No"> No
            </div>

            <div class="option-group">
                <label>Overall Rating:</label>
                <div class="rating-group">
                    <label><input type="radio" name="rating" value="1" required> 1 </label>
                    <label><input type="radio" name="rating" value="2"> 2 </label>
                    <label><input type="radio" name="rating" value="3"> 3 </label>
                    <label><input type="radio" name="rating" value="4"> 4 </label>
                    <label><input type="radio" name="rating" value="5"> 5 </label>
                </div>
            </div>

            <label for="message">Additional Comments:</label>
            <textarea name="message" id="message" rows="4"></textarea>

            <input type="submit" value="Submit Feedback" />
            <a href="index.php" class="action-btn home-btn">⬅️ Return to Homepage</a>
        </form>
    </div>
</body>
</html>
