<?php
// DB Connection
$servername = "localhost";
$username = "root"; 
$password = "";     
$dbname = "partyplot_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("DB Connection failed: " . $conn->connect_error);
}

// Get selected function_type
$function = isset($_GET['function']) ? $_GET['function'] : 'All';

// Fetch highlights
$highlight_sql = "SELECT * FROM gallery WHERE is_highlight = 1 ORDER BY uploaded_at DESC";
$highlights = $conn->query($highlight_sql);

// Fetch all media
if ($function == "All") {
    $media_sql = "SELECT * FROM gallery ORDER BY uploaded_at DESC";
} else {
    $media_sql = "SELECT * FROM gallery WHERE function_type = '" . $conn->real_escape_string($function) . "' ORDER BY uploaded_at DESC";
}
$media = $conn->query($media_sql);

// Function list
$functions = ["All", "Wedding", "Birthday", "Corporate", "Engagement", "Photoshoot", "Rooms", "Other"];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Gallery</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: #f8f9fa; text-align: center; }
        h2 { margin: 20px; }
        .nav { margin: 20px 0; }
        .nav a { padding: 10px 20px; margin: 5px; background: #4b0000; color: white; border-radius: 6px; text-decoration: none; }
        .nav a.active, .nav a:hover { background: #B7410E; }

        /* Highlight Slider */
        .highlight-slider { width: 90%; max-width: 1000px; margin: auto; overflow: hidden; position: relative; border-radius: 10px; }
        .highlight-track { display: flex; transition: transform 0.6s ease-in-out; }
        .highlight-item { min-width: 100%; box-sizing: border-box; }
        .highlight-item img, .highlight-item video { width: 100%; max-height: 500px; height: auto; object-fit: contain; background: #c6953F; border-radius: 10px; }

        /* Gallery Grid */
        .gallery { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px; padding: 20px; }
        .gallery img, .gallery video { width: 100%; max-height: 250px; height: auto; object-fit: contain; background: #000; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.2); cursor: pointer; }

        /* Lightbox */
        .lightbox { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); justify-content: center; align-items: center; z-index: 9999; }
        .lightbox-content { max-width: 90%; max-height: 90%; }
        .lightbox img, .lightbox video { max-width: 100%; max-height: 90vh; object-fit: contain; background: #000; }
        .close, .prev, .next {
            position: absolute; top: 50%; transform: translateY(-50%);
            font-size: 30px; color: white; padding: 10px; cursor: pointer; user-select: none;
        }
        .close { top: 20px; right: 30px; transform: none; font-size: 40px; }
        .prev { left: 20px; }
        .next { right: 20px; }

    body {
      margin:0;
      font-family:Arial, sans-serif;
      color:#f5f5f5;
      /* Golden + Black vignette background */
      background:#c6953F;
      /*background: radial-gradient(circle at center, #c6953F 70%, #fffff2 100%);*/
    }

    /* Header */
    .header {
      text-align:center;
      padding:20px;
      background:none;
    }
    .header img {
      max-height:150px;
    }

    /* Navigation */
    .navbar {
      background:#4b0000; /* red velvet */
      padding:12px;
      text-align:center;
    }
    .navbar a {
      margin:0 15px;
      text-decoration:none;
      font-weight:bold;
      color:white;
      transition:0.3s;
    }
    .navbar a:hover,
    .navbar a.active {
      color:#c6953F;
    }

    /* Buttons */
    .btn {
      display:inline-block;
      margin-top:20px;
      padding:12px 25px;
      font-weight:bold;
      text-decoration:none;
      border-radius:8px;
      transition:0.3s;
    }
  
    </style>
</head>
<body style="margin:0; font-family:Arial, sans-serif; background:#c6953F; color:#333;">
    <!-- Header -->
   <!-- Header with Full-Width Logo -->
<div class="header"></div>

<style>
  .header {
    width:100%;
    height:190px; /* adjust header height as you want */
    background: url('../images/aagman5.png') no-repeat center center;
    background-size: cover; /* makes image cover full width */
  }
</style>


  <!-- Navigation -->
  <?php $currentPage = basename($_SERVER['PHP_SELF']); ?>
  <div class="navbar">
    <a href="index.php" class="<?php if($currentPage=='index.php') echo 'active'; ?>">Home</a>
    <a href="client_gallery.php" class="<?php if($currentPage=='client_gallery.php') echo 'active'; ?>">Gallery</a>
    <a href="photoshoot.php" class="<?php if($currentPage=='photoshoot.php') echo 'active'; ?>">Photoshoot</a>
    <a href="packages.php" class="<?php if($currentPage=='packages.php') echo 'active'; ?>">Packages</a>
    <a href="availability.php" class="<?php if($currentPage=='availability.php') echo 'active'; ?>">Check Availability</a>
    <a href="contact.php" class="<?php if($currentPage=='contact.php') echo 'active'; ?>">Contact Us</a>
    <a href="client_about_us.php" class="<?php if($currentPage=='client_about_us.php') echo 'active'; ?>">About Us</a>
    <a href="../admin/login.php" class="<?php if($currentPage=='login.php') echo 'active'; ?>">Admin Login</a>
  </div>


    <!-- Highlight Section -->
    <?php if ($highlights->num_rows > 0): ?>
        <div class="highlight-slider" id="highlightSlider">
            <div class="highlight-track" id="highlightTrack">
                <?php while ($row = $highlights->fetch_assoc()): ?>
                    <div class="highlight-item">
                        <?php if ($row['media_type'] == 'image'): ?>
                            <img src="../uploads/<?php echo htmlspecialchars($row['file_name']); ?>" alt="Highlight">
                        <?php else: ?>
                            <video autoplay muted playsinline>
                                <source src="../uploads/<?php echo htmlspecialchars($row['file_name']); ?>" type="video/<?php echo $row['file_type']; ?>">
                            </video>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Function Navigation -->
    <div class="nav">
        <?php foreach ($functions as $fn): ?>
            <a href="?function=<?php echo urlencode($fn); ?>" 
               class="<?php echo ($function == $fn) ? 'active' : ''; ?>">
               <?php echo $fn; ?>
            </a>
        <?php endforeach; ?>
    </div>

    <!-- Gallery Media -->
    <div class="gallery">
        <?php if ($media->num_rows > 0): ?>
            <?php while ($row = $media->fetch_assoc()): ?>
                <?php if ($row['media_type'] == 'image'): ?>
                    <img src="../uploads/<?php echo htmlspecialchars($row['file_name']); ?>" 
                         data-type="image" 
                         data-src="../uploads/<?php echo htmlspecialchars($row['file_name']); ?>">
                <?php else: ?>
                    <video data-type="video" data-src="../uploads/<?php echo htmlspecialchars($row['file_name']); ?>">
                        <source src="../uploads/<?php echo htmlspecialchars($row['file_name']); ?>" type="video/<?php echo $row['file_type']; ?>">
                    </video>
                <?php endif; ?>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No media found for <?php echo htmlspecialchars($function); ?>.</p>
        <?php endif; ?>
    </div>

    <!-- Lightbox -->
    <div class="lightbox" id="lightbox">
        <span class="close" onclick="closeLightbox()">✖</span>
        <span class="prev" onclick="changeMedia(-1)">⟨</span>
        <div class="lightbox-content" id="lightboxContent"></div>
        <span class="next" onclick="changeMedia(1)">⟩</span>
    </div>

     <h2>📸 Our Gallery</h2>
    <a href="index.php" style="display:inline-block; margin:20px auto; text-align:center; padding:10px 20px; background:#555; color:white; text-decoration:none; border-radius:5px;">
        ⬅ Return to Homepage
    </a>

    <script>
        // ====== Highlight Auto-Slide with Full Video Support ======
        let highlightIndex = 0;
        const track = document.getElementById("highlightTrack");
        const highlightItems = document.querySelectorAll(".highlight-item");

        function showNextHighlight() {
            highlightIndex = (highlightIndex + 1) % highlightItems.length;
            track.style.transform = `translateX(-${highlightIndex * 100}%)`;
            handleHighlightItem();
        }

        function handleHighlightItem() {
            const currentItem = highlightItems[highlightIndex];
            const video = currentItem.querySelector("video");

            if (video) {
                video.currentTime = 0;
                video.play();
                video.onended = () => showNextHighlight(); // move after video ends
            } else {
                setTimeout(showNextHighlight, 4000); // 4s per image
            }
        }

        if (highlightItems.length > 0) {
            handleHighlightItem();
        }

        // ====== Lightbox for Gallery ======
        let mediaItems = document.querySelectorAll(".gallery img, .gallery video");
        let lightbox = document.getElementById("lightbox");
        let lightboxContent = document.getElementById("lightboxContent");
        let currentIndex = 0;

        function openLightbox(index) {
            currentIndex = index;
            showMedia();
            lightbox.style.display = "flex";
        }

        function closeLightbox() {
            lightbox.style.display = "none";
            lightboxContent.innerHTML = "";
        }

        function showMedia() {
            let item = mediaItems[currentIndex];
            let type = item.getAttribute("data-type");
            let src = item.getAttribute("data-src");

            if (type === "image") {
                lightboxContent.innerHTML = `<img src="${src}" alt="Full Image">`;
            } else {
                lightboxContent.innerHTML = `<video src="${src}" controls autoplay></video>`;
            }
        }

        function changeMedia(direction) {
            currentIndex = (currentIndex + direction + mediaItems.length) % mediaItems.length;
            showMedia();
        }

        // Add click events
        mediaItems.forEach((item, index) => {
            item.addEventListener("click", () => openLightbox(index));
        });

        // Keyboard navigation
        document.addEventListener("keydown", (e) => {
            if (lightbox.style.display === "flex") {
                if (e.key === "ArrowRight") changeMedia(1);
                if (e.key === "ArrowLeft") changeMedia(-1);
                if (e.key === "Escape") closeLightbox();
            }
        });
    </script>

</body>
</html>
