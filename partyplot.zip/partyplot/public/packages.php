<?php
include("../config/db.php");

// ✅ Fetch latest venue prices
$venue_sql = "SELECT * FROM venue_prices ORDER BY id DESC LIMIT 1";
$venue_result = $conn->query($venue_sql);
$venue = $venue_result->fetch_assoc();

// ✅ Fetch decoration prices
$decoration_sql = "SELECT * FROM decoration_prices";
$decoration_result = $conn->query($decoration_sql);

// ✅ Fetch package details
$details_sql = "SELECT * FROM package_details ORDER BY id DESC LIMIT 1";
$details_result = $conn->query($details_sql);
$details = $details_result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Our Packages</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; background: #f9f9f9; }
    .header { background: linear-gradient(135deg, #4b0000, #300B1C); padding: 20px; text-align: center; color: #c6953F; }
    .header h1 { margin: 0; font-size: 32px; }
    .container { max-width: 1100px; margin: 30px auto; background: white; padding: 25px; border-radius: 12px; border: 2px solid #c6953F; }

    .card-wrapper { display: flex; flex-wrap: wrap; gap: 20px; justify-content: space-between; }
    .card { flex: 1 1 48%; background: #fff8f0; border: 1px solid #c6953F; border-radius: 12px; padding: 20px; box-shadow: 0 4px 8px rgba(0,0,0,0.05); }
    @media (max-width: 768px) { .card { flex: 1 1 100%; } }

    h2 { color: #4b0000; margin-bottom: 10px; }
    h3 { margin: 0 0 8px; color: #4b0000; font-size: 18px; }
    label { font-weight: bold; color: #300B1C; display: block; margin-top: 10px; }
    select { width: 100%; padding: 10px; margin: 8px 0; border-radius: 6px; border: 1px solid #ccc; }

    .info-block { background: #fff3e6; border-left: 6px solid #c6953F; padding: 15px 20px; margin-bottom: 15px; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.04); }
    .info-block p { margin: 0; color: #300B1C; line-height: 1.6; }

    .price-box { background: #fdf5e6; padding: 15px; border-radius: 8px; margin-top: 20px; border: 1px solid #c6953F; font-size: 18px; }
    .btn { display: block; width: 100%; text-align: center; background: #c6953F; color: #300B1C; padding: 12px; margin-top: 20px; text-decoration: none; border-radius: 8px; font-weight: bold; cursor: pointer; }
    .btn:hover { background: gold; color: #4b0000; }
    .back-link { display: block; margin-top: 30px; text-align: center; color: #4b0000; font-weight: bold; text-decoration: none; }
    .back-link:hover { text-decoration: underline; }
  </style>
  <script>
    let totalPrice = 0; // store globally

    function calculatePrice() {
        let ground = <?= $venue['ground_price']; ?>;
        let dome = <?= $venue['dome_price']; ?>;
        let room = <?= $venue['room_price']; ?>;

        let venueSelect = document.getElementById("venue").value;
        let withDeco = document.getElementById("decoration").value;

        let basePrice = 0;
        if (venueSelect.includes("Ground")) basePrice += ground;
        if (venueSelect.includes("Dome")) basePrice += dome;
        if (venueSelect.includes("Rooms")) basePrice += room;

        let decoPrice = 0;
        if (withDeco === "with") {
            let functionType = document.getElementById("function").value;
            let prices = {
                <?php
                $jsArr = [];
                mysqli_data_seek($decoration_result, 0);
                while ($row = $decoration_result->fetch_assoc()) {
                    $jsArr[] = '"' . $row['function_type'] . '": ' . $row['approx_price'];
                }
                echo implode(",", $jsArr);
                ?>
            };
            decoPrice = prices[functionType] || 0;
        }

        totalPrice = basePrice + decoPrice;
        document.getElementById("totalPrice").innerText = "Approx. Total Price: ₹ " + totalPrice.toLocaleString();
    }

    function goToBooking() {
        let functionType = document.getElementById("function").value;
        let venue = document.getElementById("venue").value;
        let decoration = document.getElementById("decoration").value;

        // Redirect with price
        window.location.href = "booking.php?function=" + encodeURIComponent(functionType) +
                               "&venue=" + encodeURIComponent(venue) +
                               "&decoration=" + encodeURIComponent(decoration) +
                               "&price=" + encodeURIComponent(totalPrice);
    }
  </script>
</head>
<body onload="calculatePrice()">

  <div class="header">
    <h1>🎁 Our Packages</h1>
    <p>Select your perfect event package</p>
  </div>
  <a href="index.php" class="back-link">⬅ Back</a>

  <div class="container">
    <div class="card-wrapper">
      <!-- 🏛 Package Details Card -->
      <div class="card">
        <h2>🏛 Package Highlights</h2>

        <div class="info-block">
          <h3>🎉 Facilities</h3>
          <p><?= nl2br($details['facilities']); ?></p>
        </div>

        <div class="info-block">
          <h3>👥 Guest Capacity</h3>
          <p><?= $details['guest_capacity']; ?> guests</p>
        </div>

        <div class="info-block">
          <h3>⏳ Duration</h3>
          <p><?= $details['duration']; ?></p>
        </div>

        <div class="info-block">
          <h3>🛎 Services Included</h3>
          <p><?= nl2br($details['services']); ?></p>
        </div>

        <div class="info-block">
          <h3>📜 Policies</h3>
          <p><?= nl2br($details['policies']); ?></p>
        </div>

        <div class="info-block">
          <h3>❌ Cancellation Policy</h3>
          <p><?= nl2br($details['cancellation_policy']); ?></p>
        </div>

        <div class="info-block">
          <h3>🔍 Additional Info</h3>
          <p><?= nl2br($details['other_details']); ?></p>
        </div>
      </div>

      <!-- 📝 Customize Your Package Card -->
      <div class="card">
        <h2>📝 Customize Your Package</h2>

        <label for="function">Select Function</label>
        <select id="function" onchange="calculatePrice()">
          <?php
          mysqli_data_seek($decoration_result, 0);
          while ($row = $decoration_result->fetch_assoc()) {
              echo "<option value='{$row['function_type']}'>{$row['function_type']}</option>";
          }
          ?>
        </select>

        <label for="decoration">Decoration</label>
        <select id="decoration" onchange="calculatePrice()">
          <option value="without">Without Decoration</option>
          <option value="with">With Decoration</option>
        </select>

        <label for="venue">Select Venue</label>
        <select id="venue" onchange="calculatePrice()">
          <option value="Ground">Ground</option>
          <option value="Dome">Dome</option>
          <option value="Ground+Dome">Ground + Dome</option>
          <option value="Ground+Rooms">Ground + Rooms</option>
          <option value="Dome+Rooms">Dome + Rooms</option>
          <option value="Ground+Dome+Rooms">Ground + Dome + Rooms</option>
        </select>

        <div class="price-box" id="totalPrice">Approx. Total Price: ₹ 0</div>
        <button type="button" class="btn" onclick="goToBooking()">📅 Book Now</button>
      </div>
    </div>
  <a href="index.php" class="back-link">⬅ Back</a>
  

    
  </div>

</body>
</html>
