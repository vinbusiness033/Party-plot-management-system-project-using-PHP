<?php
session_start();
include("../config/db.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $bookingId = $_POST['booking_id'] ?? 0;
    $price = $_POST['price'] ?? 0;

    // ✅ Update booking status
    $stmt = $conn->prepare("UPDATE bookings SET status='Confirmed' WHERE id=?");
    $stmt->bind_param("i", $bookingId);
    $stmt->execute();
    $stmt->close();

    // ✅ Fetch booking details
    $res = $conn->query("SELECT * FROM bookings WHERE id=$bookingId");
    $booking = $res->fetch_assoc();
    $res->close();
} else {
    die("⚠ Invalid request.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment Success</title>
    <style>
        body { font-family: Arial, sans-serif; background:#f8f8f8; margin:0; padding:40px; }
        .invoice { max-width:700px; margin:auto; background:white; padding:20px; border-radius:10px; 
                  border:2px solid #4CAF50; box-shadow:0 4px 12px rgba(0,0,0,0.06);}
        h2 { color:#2e7d32; text-align:center; }
        table { width:100%; border-collapse:collapse; margin-top:20px; }
        td, th { border:1px solid #ccc; padding:10px; text-align:left; }
        th { background:#f4f4f4; }
    </style>
</head>
<body>
<div class="invoice">
    <h2>✅ Payment Successful</h2>
    <p style="text-align:center;">Thank you, <?= htmlspecialchars($booking['name']) ?>! Your booking is confirmed.</p>

    <h3>📄 Invoice</h3>
    <table>
        <tr><th>Booking ID</th><td><?= $booking['id'] ?></td></tr>
        <tr><th>Name</th><td><?= htmlspecialchars($booking['name']) ?></td></tr>
        <tr><th>Email</th><td><?= htmlspecialchars($booking['email']) ?></td></tr>
        <tr><th>Phone</th><td><?= htmlspecialchars($booking['phone']) ?></td></tr>
        <tr><th>Function</th><td><?= htmlspecialchars($booking['function']) ?></td></tr>
        <tr><th>Venue</th><td><?= htmlspecialchars($booking['venue']) ?></td></tr>
        <tr><th>Decoration</th><td><?= htmlspecialchars($booking['decoration']) ?></td></tr>
        <tr><th>Guests</th><td><?= htmlspecialchars($booking['guests']) ?></td></tr>
        <tr><th>Event Dates</th><td><?= htmlspecialchars($booking['event_date']) ?></td></tr>
        <tr><th>Total Price</th><td>₹ <?= number_format($booking['total_price'], 2) ?></td></tr>
        <tr><th>Status</th><td><?= $booking['status'] ?></td></tr>
    </table>
</div>
</body>
</html>
