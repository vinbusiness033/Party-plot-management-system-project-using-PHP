<?php
include("../config/db.php");

// ✅ Fetch latest settings from database
$sql = "SELECT * FROM photoshoot_settings ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);
$settings = $result->fetch_assoc();

$base_price = $settings['base_price'];
$included_persons = $settings['included_persons'];
$extra_person_price = $settings['extra_person_price'];

// Get today's date in yyyy-mm-dd format to restrict past dates
$today = date('Y-m-d');

// ✅ Handle booking form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $date = $_POST['date'];
    $persons = $_POST['persons'];
    $amount = $_POST['amount'];

    $sql = "INSERT INTO photoshoots (name, email, phone, persons, date, total_price, payment_status) 
            VALUES ('$name', '$email', '$phone', '$persons', '$date', '$amount', 'unpaid')";

    if ($conn->query($sql) === TRUE) {
        $last_id = $conn->insert_id;  
        header("Location: photoshoot_bill.php?id=" . $last_id);
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Photoshoot Booking</title>
    <style>
    body {
      margin:0;
      font-family:Arial, sans-serif;
      color:#f5f5f5;
      /* Golden + Black vignette background */
      background:#c6953F;
      /*background: radial-gradient(circle at center, #c6953F 70%, #fffff2 100%);*/
    }

    /* Header */
    .header {
      text-align:center;
      padding:20px;
      background:none;
    }
    .header img {
      max-height:150px;
    }

    /* Navigation */
    .navbar {
      background:#4b0000; /* red velvet */
      padding:12px;
      text-align:center;
    }
    .navbar a {
      margin:0 15px;
      text-decoration:none;
      font-weight:bold;
      color:white;
      transition:0.3s;
    }
    .navbar a:hover,
    .navbar a.active {
      color:#c6953F;
    }

    /* Cards */
    .features {
      display:grid;
      grid-template-columns:repeat(auto-fit, minmax(250px, 1fr));
      gap:20px;
      margin-top:20px;
    }
    .card {
      background:#4b0000; /* deep maroon */
      color:white;
      padding:20px;
      border-radius:12px;
      border:2px solid gold;
      box-shadow:0px 4px 10px rgba(0,0,0,0.6);
    }

    /* Buttons */
    .btn {
      display:inline-block;
      margin-top:20px;
      padding:12px 25px;
      font-weight:bold;
      text-decoration:none;
      border-radius:8px;
      transition:0.3s;
    }
    .btn-gold {
      background:#300B1C;
      color:#f9f1f1;
    }
    .btn-gold:hover {
      background:#4b0000;
    }
    .btn-maroon {
      background:#300B1C;
      color:#f9f1f1;
    }
    .btn-maroon:hover {
      background:#4b0000;
    }

    /* Labels in golden */
    label {
      font-weight:bold; 
      color:#c6953F; 
      display:block; 
      margin-top:10px;
    }

    /* Common input styles */
    input[type="text"],
    input[type="email"],
    input[type="date"],
    input[type="number"] {
      width:97%;
      padding:10px;
      margin:5px 0;
      border:2px solid gold;
      border-radius:6px;
      background:#1c1c1c;  /* black background */
      color:white;
      font-size:16px;
    }

    /* Focus effect */
    input:focus {
      border-color:#800000; /* maroon velvet */
      outline:none;
      background:#2b0000;
    }

    /* Readonly amount box */
    #amount {
      background:#1c1c1c; 
      color:white; 
      font-weight:bold;
    }
    </style>
     
</head>
<body>
    <div class="header"></div>

<style>
  .header {
    width:100%;
    height:190px; /* adjust header height as you want */
    background: url('../images/aagman5.png') no-repeat center center;
    background-size: cover; /* makes image cover full width */
  }
</style>

  <!-- Navigation -->
  <?php $currentPage = basename($_SERVER['PHP_SELF']); ?>
  <div class="navbar">
    <a href="index.php" class="<?php if($currentPage=='index.php') echo 'active'; ?>">Home</a>
    <a href="client_gallery.php" class="<?php if($currentPage=='client_gallery.php') echo 'active'; ?>">Gallery</a>
    <a href="photoshoot.php" class="<?php if($currentPage=='photoshoot.php') echo 'active'; ?>">Photoshoot</a>
    <a href="packages.php" class="<?php if($currentPage=='packages.php') echo 'active'; ?>">Packages</a>
    <a href="availability.php" class="<?php if($currentPage=='availability.php') echo 'active'; ?>">Check Availability</a>
    <a href="contact.php" class="<?php if($currentPage=='contact.php') echo 'active'; ?>">Contact Us</a>
    <a href="client_about_us.php" class="<?php if($currentPage=='client_about_us.php') echo 'active'; ?>">About Us</a>
    <a href="../admin/login.php" class="<?php if($currentPage=='login.php') echo 'active'; ?>">Admin Login</a>
  </div>

  <!-- Booking Form -->
  <div style="padding:30px; max-width:800px; margin:auto;">
    <h2 style="color:#121318; text-align:center;">Photoshoot Booking</h2>
    <form method="POST" style="max-width:600px; margin:auto; padding:20px; border:2px solid gold; border-radius:10px; background:#4b0000;">

        <label style="font-weight:bold; color:#c6953F">Name:</label><br>
        <input type="text" name="name" required 
         style="width:97%; padding:10px; margin:5px 0; 
         border:2px solid gold; 
         border-radius:6px; 
         background:#1c1c1c; 
         color:white; 
         font-size:16px;">

        <label for="email">Email:</label>
        <input type="email" name="email" required 
         pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" 
         title="Enter a valid email address"
         placeholder="username@gmail.com">

        <label for="phone">Phone Number:</label>
        <input type="text" name="phone" id="phone" required maxlength="14"
         pattern="\+91\s\d{10}" 
         placeholder="+91 9999999999"
         title="Enter a valid phone number in the format +91 9824598012">

        <label>Select Date:</label>
        <input type="date" name="date" required min="<?php echo $today; ?>">

        <label>Number of Persons:</label>
        <input type="number" id="persons" name="persons" min="1" value="1" required 
         oninput="calculateAmount()">

        <label>Total Amount (₹):</label>
        <input type="text" id="amount" name="amount" readonly>

        <div style="text-align:center; margin-top:15px;">
          <button type="submit" 
                  style="width:60%; padding:10px; background:#333; color:white; 
                          border:2px solid gold; border-radius:5px; font-size:16px; 
                          cursor:pointer; transition:0.3s;">
         Book Now
      </button>
    </div>
    </form>
    
  </div>

  <script>
        function calculateAmount() {
            let persons = document.getElementById("persons").value;

            let basePrice = <?php echo $base_price; ?>;
            let includedPersons = <?php echo $included_persons; ?>;
            let extraPrice = <?php echo $extra_person_price; ?>;

            let extra = 0;
            if (persons > includedPersons) {
                extra = (persons - includedPersons) * extraPrice;
            }
            let total = basePrice + extra;
            document.getElementById("amount").value = total;
        }

        // ✅ run once on page load
        window.onload = calculateAmount;
  </script>

</body>
</html>
