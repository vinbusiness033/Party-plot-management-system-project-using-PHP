<?php include '../config/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Aagman Event & Party Plot</title>
  <style>
    body {
      margin:0;
      font-family:Arial, sans-serif;
      color:#f5f5f5;
      /* Golden + Black vignette background */
      background:#c6953F;
      /*background: radial-gradient(circle at center, #c6953F 70%, #fffff2 100%);*/
    }

    /* Header */
    .header {
      text-align:center;
      padding:20px;
      background:none;
    }
    .header img {
      max-height:150px;
    }

    /* Navigation */
    .navbar {
      background:#4b0000; /* red velvet */
      padding:12px;
      text-align:center;
    }
    .navbar a {
      margin:0 15px;
      text-decoration:none;
      font-weight:bold;
      color:white;
      transition:0.3s;
    }
    .navbar a:hover,
    .navbar a.active {
      color:#c6953F;
    }

    /* Cards */
    .features {
      display:grid;
      grid-template-columns:repeat(auto-fit, minmax(250px, 1fr));
      gap:20px;
      margin-top:20px;
    }
    .card {
      background:#4b0000; /* deep maroon */
      color:white;
      padding:20px;
      border-radius:12px;
      border:2px solid gold;
      box-shadow:0px 4px 10px rgba(0,0,0,0.6);
    }

    /* Buttons */
    .btn {
      display:inline-block;
      margin-top:20px;
      padding:12px 25px;
      font-weight:bold;
      text-decoration:none;
      border-radius:8px;
      transition:0.3s;
    }
    .btn-gold {
      background:#300B1C;
      color:#f9f1f1;
    }
    .btn-gold:hover {
      background:#4b0000;
    }
    .btn-maroon {
      background:#300B1C;
      color:#f9f1f1;
    }
    .btn-maroon:hover {
      background:#4b0000;
    }
  </style>
</head>
<body>

  <!-- Header with Full-Width Logo -->
<div class="header"></div>

<style>
  .header {
    width:100%;
    height:190px; /* adjust header height as you want */
    background: url('../images/aagman5.png') no-repeat center center;
    background-size: cover; /* makes image cover full width */
  }
</style>


  <!-- Navigation -->
  <?php $currentPage = basename($_SERVER['PHP_SELF']); ?>
  <div class="navbar">
    <a href="index.php" class="<?php if($currentPage=='index.php') echo 'active'; ?>">Home</a>
    <a href="client_gallery.php" class="<?php if($currentPage=='client_gallery.php') echo 'active'; ?>">Gallery</a>
    <a href="photoshoot.php" class="<?php if($currentPage=='photoshoot.php') echo 'active'; ?>">Photoshoot</a>
    <a href="packages.php" class="<?php if($currentPage=='packages.php') echo 'active'; ?>">Packages</a>
    <a href="feedback.php" class="<?php if($currentPage=='feedback.php') echo 'active'; ?>">Feedback</a>
    <a href="contact.php" class="<?php if($currentPage=='contact.php') echo 'active'; ?>">Contact Us</a>
    <a href="client_about_us.php" class="<?php if($currentPage=='client_about_us.php') echo 'active'; ?>">About Us</a>
    <a href="../admin/login.php" class="<?php if($currentPage=='login.php') echo 'active'; ?>">Admin Login</a>
  </div>

  <!-- Main Content -->
  <div style="padding:30px; max-width:1100px; margin:auto;">
    <h2 style="color:#121318;">Why Choose Our Party Plot?</h2>
    <div class="features">
      <div class="card">🚗 Large Parking Space</div>
      <div class="card">🎉 Decoration Services</div>
      <div class="card">🏟 Spacious Ground</div>
      <div class="card">🏛 2 Luxury Domes</div>
      <div class="card">👥 Capacity up to 2500 Guests</div>
      <div class="card">📸 Photoshoot Themes</div>
      <div class="card">❄️ Fully AC Rooms</div>
      <div class="card">🏊 Swimming Pool</div>
    </div>

    <a href="packages.php" class="btn btn-gold">📅 Book Now</a>
    <a href="photoshoot.php" class="btn btn-maroon">📸 Book Photoshoot</a>  
  </div>

</body>
</html>
