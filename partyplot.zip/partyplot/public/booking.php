<?php
include("../config/db.php");

$function_type = isset($_GET['function']) ? $_GET['function'] : '';
$venue = isset($_GET['venue']) ? $_GET['venue'] : '';
$decoration = isset($_GET['decoration']) ? $_GET['decoration'] : '';
$total_price = isset($_GET['price']) ? floatval($_GET['price']) : 0.0;

$error = '';
$booked_dates = [];
$dates_sql = "SELECT event_date FROM booking_dates";
$result = $conn->query($dates_sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $booked_dates[] = $row['event_date'];
    }
}

$blocked_dates = [];
$blocked_sql = "SELECT blocked_date FROM blocked_dates";
$res_blocked = $conn->query($blocked_sql);
if ($res_blocked) {
    while ($row = $res_blocked->fetch_assoc()) {
        $blocked_dates[] = $row['blocked_date'];
    }
}

$disabled_dates = array_unique(array_merge(array_values($booked_dates), array_values($blocked_dates)));
// Re-index to zero-based array for proper JSON encoding to array
$disabled_dates = array_values($disabled_dates);

if ($decoration === 'with') {
    $decoration_enum = 'With Decoration';
} else {
    $decoration_enum = 'Without Decoration';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $client_name = $conn->real_escape_string(trim($_POST['client_name']));
    $phone = $conn->real_escape_string(trim($_POST['phone']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $guests = intval($_POST['guests']);
    $special_requirements = $conn->real_escape_string(trim($_POST['special_requirements']));
    $event_dates_raw = trim($_POST['event_dates']);
    $event_dates_arr = explode(',', $event_dates_raw);
    $event_dates_arr = array_filter(array_map('trim', $event_dates_arr));

    if (!$client_name || !$phone || !$event_dates_raw || !$guests) {
        $error = "Please fill in all required fields and select event dates.";
    } elseif (count($event_dates_arr) > 4) {
        $error = "You can select a maximum of 4 dates only. For more dates, please contact us.";
    } else {
        $intersection = array_intersect($event_dates_arr, $disabled_dates);
        if (count($intersection) > 0) {
            $error = "One or more selected dates are already booked or blocked: " . implode(", ", $intersection);
        } else {
            $stmt = $conn->prepare("INSERT INTO bookings(client_name, phone, email, function_type, venue, decoration_option, guests, special_requirements, total_price, status)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $status = 'Pending';
            $stmt->bind_param("ssssssisss", $client_name, $phone, $email, $function_type, $venue, $decoration_enum, $guests, $special_requirements, $total_price, $status);
            if ($stmt->execute()) {
                $booking_id = $stmt->insert_id;
                $stmt->close();

                $stmt_date = $conn->prepare("INSERT INTO booking_dates (booking_id, event_date) VALUES (?, ?)");
                foreach ($event_dates_arr as $date) {
                    $stmt_date->bind_param("is", $booking_id, $date);
                    $stmt_date->execute();
                }
                $stmt_date->close();

                header("Location: package_bill.php?booking_id=" . $booking_id);
                exit();
            } else {
                $error = "Failed to save booking.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Confirm Your Booking</title>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css" />
<style>
    body {
        font-family: Arial, sans-serif;
        background: #f9f9f9;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 700px;
        margin: 30px auto;
        background: white;
        padding: 25px;
        border-radius: 12px;
        border: 2px solid #c6953F;
    }
    h1 {
        color: #4b0000;
        text-align: center;
    }
    label {
        display: block;
        margin: 15px 0 5px;
        font-weight: bold;
        color: #300B1C;
    }
    input[type="text"],
    input[type="email"],
    input[type="tel"],
    input[type="number"],
    textarea {
        width: 100%;
        padding: 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 1em;
    }
    button {
        background: #c6953F;
        color: #300B1C;
        border: none;
        font-weight: bold;
        padding: 15px;
        border-radius: 8px;
        cursor: pointer;
        width: 100%;
        margin-top: 20px;
    }
    button:hover {
        background: gold;
        color: #4b0000;
    }
    .error {
        color: #b00000;
        background: #ffd4d4;
        padding: 10px;
        border-radius: 6px;
        margin-bottom: 15px;
    }
    .ui-datepicker-multi {
        width: 350px !important;
    }
    #selectedDatesDisplay {
        margin-top: 10px;
        font-weight: bold;
        color: #4b0000;
    }
    .back-link {
        display: inline-block;
        margin-top: 15px;
        color: #4b0000;
        text-decoration: none;
        font-weight: bold;
    }
    .back-link:hover {
        text-decoration: underline;
    }
</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-ui-multidatespicker/jquery-ui.multidatespicker.min.js"></script>
<script>
$(function () {
    var disabledDates = <?= json_encode($disabled_dates); ?>;
    var selectedDatesLimit = 4;
    $('#datepicker').multiDatesPicker({
        dateFormat: 'yy-mm-dd',
        maxPicks: selectedDatesLimit,
        minDate: 0,
        beforeShowDay: function (date) {
            var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
            return [disabledDates.indexOf(string) === -1];
        },
        onSelect: function () {
            var dates = $('#datepicker').multiDatesPicker('getDates');
            if (dates.length >= selectedDatesLimit) {
                alert('Maximum ' + selectedDatesLimit + ' dates can be selected. For more dates, please contact us.');
            }
            $('#event_dates').val(dates.join(','));
            if (dates.length === 0) {
                $('#selectedDatesDisplay').html('No dates selected');
            } else {
                $('#selectedDatesDisplay').html('Selected Dates: ' + dates.join(', '));
            }
        }
    });
});
</script>
</head>
<body>
<div class="container">
    <a href="packages.php" class="back-link">&#8592; Back to Packages</a>
    <h1>Confirm Your Booking</h1>
    <?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <div>
        <p><strong>Function:</strong> <?= htmlspecialchars($function_type) ?></p>
        <p><strong>Venue:</strong> <?= htmlspecialchars($venue) ?></p>
        <p><strong>Decoration:</strong> <?= ($decoration === 'with') ? 'With Decoration' : 'Without Decoration' ?></p>
        <p><strong>Approximate Price:</strong> ₹ <?= number_format($total_price, 2) ?></p>
    </div>
    <form method="post" action="">
        <label for="datepicker">Select Event Dates (up to 4)</label>
        <div id="datepicker"></div>
        <input type="hidden" id="event_dates" name="event_dates" required />
        <div id="selectedDatesDisplay">No dates selected</div>
        <label for="client_name">Full Name</label>
        <input type="text" id="client_name" name="client_name" required maxlength="100" />

        <label for="phone">Phone Number:</label>
        <input type="text" name="phone" id="phone" required maxlength="14"
         pattern="\+91\s\d{10}" 
         placeholder="+91 9999999999"
         title="Enter a valid phone number in the format +91 9824598012">


        <!--<label for="phone">Phone Number</label>
        <input type="tel" id="phone" name="phone" required maxlength="20" pattern="[0-9+\-\s]+" />-->

        <label for="email">Email:</label>
        <input type="email" name="email" required 
         pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" 
         title="Enter a valid email address"
         placeholder="username@gmail.com">

        <!--<label for="email">Email (optional)</label>
        <input type="email" id="email" name="email" maxlength="100" />-->

        <label for="guests">Number of Guests</label>
        <input type="number" id="guests" name="guests" required min="1" max="2500" placeholder="Up to 2500"/>

        <label for="special_requirements">Special Requirements (optional)</label>
        <textarea id="special_requirements" name="special_requirements" rows="4"></textarea>
        <button type="submit">Confirm Booking</button>
        <a href="packages.php" class="back-link">&#8592; Back to Packages</a>
    </form>
</div>
</body>
</html>
