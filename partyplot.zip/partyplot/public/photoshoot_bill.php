<?php
include("../config/db.php");

if (!isset($_GET['id'])) {
    die("<p style='color:red;'>❌ Invalid Request</p>");
}
$ps_id = $_GET['id'];

$sql = "SELECT * FROM photoshoots WHERE ps_id = '$ps_id'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    die("<p style='color:red;'>❌ Booking not found</p>");
}

$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Photoshoot Bill</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #c6953F;
            color: #300B1C;
            margin: 0;
            padding: 40px 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            color: #4b0000;
            text-align: center;
            margin-bottom: 30px;
        }

        .bill-box {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            max-width: 600px;
            width: 100%;
        }

        .bill-box p {
            margin: 10px 0;
            font-size: 16px;
        }

        .status {
            font-weight: bold;
        }

        .paid {
            color: green;
        }

        .unpaid {
            color: red;
        }

        .action-btn {
            display: block;
            width: 97%;
            padding: 12px;
            margin-top: 15px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
        }

        .pay-btn {
            background: #4b0000;
            color: #c6953F;
        }

        .pay-btn:hover {
            background: #ffa600ff;
            color: #300B1C;
        }

        .print-btn {
            background: green;
            color: white;
        }

        .print-btn:hover {
            opacity: 0.9;
        }

        .back-btn {
            background: #4b0000;
            color: #c6953F;
           display: block;
            width: 100%;
            padding: 12px;
            margin-top: 15px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
        }

        hr {
            margin: 25px 0;
            border: none;
            border-top: 1px solid #ccc;
        }
    </style>
</head>
<body>

    <h2>📄 Photoshoot Bill</h2>

    <div class="bill-box">
        <p><b>Booking ID:</b> <?php echo $row['ps_id']; ?></p>
        <p><b>Name:</b> <?php echo $row['name']; ?></p>
        <p><b>Email:</b> <?php echo $row['email']; ?></p>
        <p><b>Phone:</b> <?php echo $row['phone']; ?></p>
        <p><b>Date:</b> <?php echo $row['date']; ?></p>
        <p><b>No. of Persons:</b> <?php echo $row['persons']; ?></p>
        <p><b>Total Price:</b> ₹<?php echo $row['total_price']; ?></p>
        <p><b>Payment Status:</b> 
            <span class="status <?php echo ($row['payment_status']=='paid') ? 'paid' : 'unpaid'; ?>">
                <?php echo ucfirst($row['payment_status']); ?>
            </span>
        </p>

        <hr>
        <h2  style="color: #db0000ff">🙂Payment required to confirm photoshoots!!</h2>

        <?php if ($row['payment_status'] == 'unpaid') { ?>
            <a href="payment_success.php?id=<?php echo $row['ps_id']; ?>" class="action-btn pay-btn">💳 Pay Now</a>
        <?php } else { ?>
            <p class="paid">✅ Payment Completed</p>
            <button onclick="window.print()" class="action-btn print-btn">🖨 Print Bill</button>
        <?php } ?>

        <button onclick="window.history.back()" class="back-btn">⬅ Back</button>
    </div>

</body>
</html>
