<?php
include("../config/db.php");

if (isset($_GET['id'])) {
    $booking_id = intval($_GET['id']);
    $conn->query("UPDATE photoshoots SET payment_status='paid' WHERE ps_id=$booking_id");
    $result = $conn->query("SELECT * FROM photoshoots WHERE ps_id=$booking_id");
    $row = $result->fetch_assoc();
} else {
    die("<p style='color:red;'>❌ Invalid booking request.</p>");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment Success</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #c6953F;
            color: #300B1C;
            margin: 0;
            padding: 40px 20px;
            text-align: center;
        }

        h2 {
            color: green;
            margin-bottom: 10px;
        }

        p {
            font-size: 16px;
            margin: 8px 0;
        }

        .bill-box {
            background: #fff;
            display: inline-block;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            margin-top: 30px;
            text-align: left;
            max-width: 500px;
        }

        .bill-box h3 {
            color: #4b0000;
            margin-bottom: 20px;
            text-align: center;
        }

        .status {
            font-weight: bold;
            color: green;
        }

        .button-group {
            margin-top: 30px;
        }

        .action-btn {
            display: inline-block;
            margin: 10px;
            padding: 12px 24px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
        }

        .print-btn {
            background: #4b0000;
            color: #c6953F;
        }

        .print-btn:hover {
            background: #300B1C;
        }

        .home-btn {
            background: #4b0000;
            color: #c6953F;
        }
    </style>
</head>
<body>

    <h2>✅ Payment Successful</h2>
    <p>Thank you, <b><?php echo $row['name']; ?></b>. Your payment has been confirmed.</p>
    <h3 style="color: #b20000ff">"You must show this bill at the gate at the time of entry!!"</h3>

    <div class="bill-box">
        <h3>📄 Photoshoot Bill</h3>
        <p><b>Booking ID:</b> <?php echo $row['ps_id']; ?></p>
        <p><b>Name:</b> <?php echo $row['name']; ?></p>
        <p><b>Email:</b> <?php echo $row['email']; ?></p>
        <p><b>Phone:</b> <?php echo $row['phone']; ?></p>
        <p><b>Date:</b> <?php echo $row['date']; ?></p>
        <p><b>No. of Persons:</b> <?php echo $row['persons']; ?></p>
        <p><b>Total Price:</b> ₹<?php echo $row['total_price']; ?></p>
        <p><b>Payment Status:</b> <span class="status">Paid</span></p>
    </div>

    <div class="button-group">
        <button onclick="window.print()" class="action-btn print-btn">🖨️ Print Bill</button>
        <a href="index.php" class="action-btn home-btn">⬅️ Return to Homepage</a>
    </div>

</body>
</html>
