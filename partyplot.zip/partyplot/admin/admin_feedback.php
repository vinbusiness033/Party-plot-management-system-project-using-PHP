<?php
include("../config/db.php");
$sql = "SELECT * FROM feedback ORDER BY submitted_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - View Feedback</title>
    <style>
        body { font-family: Arial, sans-serif; background: #c6953F; color: #4b0000; padding:20px; }
        .container { max-width:900px; margin:auto; background:#4b0000; color:white; padding:24px; border-radius:10px; }
        h2 { color: #c6953F; text-align: center;}
        table { width:100%; border-collapse:collapse; margin-top:24px; }
        th, td { border:1px solid #c6953F; padding:10px; text-align:left;}
        th { background: #300B1C;}
        tr:nth-child(even) { background: #3a0000;}
    </style>
</head>
<body>
    <div class="container">
        <h2>Client Feedback & Ratings</h2>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>booking process</th>
                    <th>gallery</th>
                    <th>recommend</th>
                    <th>Rating</th>
                    <th>Comments</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['submitted_at']; ?></td>
                            <td><?php echo htmlspecialchars($row['client_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['client_email']); ?></td>
                            <td><?php echo htmlspecialchars($row['quiz1']); ?></td>
                            <td><?php echo htmlspecialchars($row['quiz2']); ?></td>
                            <td><?php echo htmlspecialchars($row['quiz3']); ?></td>
                            <td><?php echo $row['rating']; ?></td>
                            <td><?php echo nl2br(htmlspecialchars($row['message'])); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align:center;">No feedback found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
         <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
    </div>
                       

</body>
</html>
