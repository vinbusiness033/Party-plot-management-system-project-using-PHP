<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Photoshoot</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #c6953F;
            color: #FFD700;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        .header {
            background: #3c0000ff;
            width: 100%;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        }

        .header h2 {
            margin: 0;
            font-size: 30px;
            color: #c6953F;
        }

        .content {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }

        .icon {
            color: #300B1C;
            font-size: 40px;
            margin-bottom: 30px;
        }

        .button-group {
            display: flex;
            flex-direction: column;
            gap: 20px;
            align-items: center;
        }

        .option-button {
            background: #4b0000;
            color: #c6953F;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            text-decoration: none;
            transition: background 0.3s ease, color 0.3s ease;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
        }

        .option-button:hover {
            background: #310000ff;
        }

        .back-link {
            display: inline-block;
            margin-top: 40px;
            padding: 10px 20px;
            background: #300B1C;
            color: #c6953F;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }

    </style>
</head>
<body>

    <div class="header">
        <h2>📸 Manage Photoshoot</h2>
    </div>

    <div class="content">
        <div class="icon">select any option</div>
        <div class="button-group">
            <a href="update_photoshoot_price.php" class="option-button">✏️ Update Photoshoot Price</a>
            <a href="admin_photoshoot_report.php" class="option-button">📊 Total Photoshoots (Monthly)</a>
        </div>
        <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
    </div>

</body>
</html>
