<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['admin_id'])) {
    die("❌ Access denied. Please login as admin.");
}

// ADD ADMIN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['password'])) {
    $username = trim($_POST['username']);
    $password = md5($_POST['password']);

    $check = $conn->query("SELECT * FROM admins WHERE username='$username'");
    if ($check->num_rows > 0) {
        $_SESSION['msg'] = "⚠️ Username already exists!";
    } else {
        $sql = "INSERT INTO admins (username, password) VALUES ('$username', '$password')";
        $_SESSION['msg'] = $conn->query($sql)
            ? "✅ New admin created successfully!"
            : "❌ Error: " . $conn->error;
    }
    header("Location: register.php");
    exit;
}

// DELETE ADMIN
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $_SESSION['msg'] = ($delete_id == $_SESSION['admin_id'])
        ? "⚠️ You cannot delete your own account!"
        : ($conn->query("DELETE FROM admins WHERE id=$delete_id")
            ? "✅ Admin deleted successfully!"
            : "❌ Error deleting admin.");
    header("Location: register.php");
    exit;
}

$admins = $conn->query("SELECT * FROM admins ORDER BY id ASC");
$msg = $_SESSION['msg'] ?? "";
unset($_SESSION['msg']);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Admins</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #c6953F;
            color: #300B1C;
            margin: 0;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #4b0000;
            margin-bottom: 20px;
        }

        form {
            text-align: center;
            margin-bottom: 30px;
        }

        input[type="text"], input[type="password"] {
            padding: 10px;
            margin: 5px;
            border-radius: 6px;
            border: 1px solid #4b0000;
            width: 200px;
        }

        button {
            padding: 10px 20px;
            background: #4b0000;
            color: #FFD700;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #FFD700;
            color: #300B1C;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }

        th {
            background: #4b0000;
            color: #c6953F;
        }

        tr:nth-child(even) {
            background: #f9f9f9;
        }

        .delete-btn {
            background: red;
            color: white;
            padding: 6px 12px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }

        .delete-btn:hover {
            background: darkred;
        }

        .back-link {
            display: inline-block;
            margin-top: 30px;
            padding: 10px 20px;
            background: #4b0000;
            color: #c6953F;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }

        .message {
            text-align: center;
            font-weight: bold;
            margin-bottom: 20px;
            color: #4b0000;
        }
    </style>
</head>
<body>

    <h2>👤 Manage Admins</h2>

    <?php if ($msg): ?>
        <div class="message"><?php echo $msg; ?></div>
    <?php endif; ?>

    <!-- Add Admin Form -->
    <form method="post">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">➕ Add Admin</button>
    </form>

    <!-- Admin List -->
    <h3 style="color:#4b0000;">📋 Existing Admins</h3>
    <table>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $admins->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo htmlspecialchars($row['username']); ?></td>
            <td>
                <?php if ($row['id'] != $_SESSION['admin_id']): ?>
                    <a href="?delete_id=<?php echo $row['id']; ?>" 
                       class="delete-btn" 
                       onclick="return confirm('Are you sure you want to delete this admin?')">❌ Delete</a>
                <?php else: ?>
                    (You)
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <div style="text-align:center;">
        <a href="dashboard.php" class="back-link">⬅️ Back to Dashboard</a>
    </div>

</body>
</html>
