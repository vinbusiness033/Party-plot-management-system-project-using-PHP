<?php
session_start();
include("../config/db.php");

$status = $_GET['status'] ?? '';
$client_name = trim($_GET['client_name'] ?? '');
$event_date = $_GET['event_date'] ?? '';
$function_type = trim($_GET['function_type'] ?? '');
$venue = trim($_GET['venue'] ?? '');

$where = [];
$params = [];
$types = '';

if ($status) {
    $where[] = 'b.status = ?';
    $params[] = $status;
    $types .= 's';
}
if ($client_name) {
    $where[] = "b.client_name LIKE ?";
    $params[] = '%' . $client_name . '%';
    $types .= 's';
}
if ($function_type) {
    $where[] = "b.function_type LIKE ?";
    $params[] = '%' . $function_type . '%';
    $types .= 's';
}
if ($venue) {
    $where[] = "b.venue LIKE ?";
    $params[] = '%' . $venue . '%';
    $types .= 's';
}

$where_sql = '';
if ($where) {
    $where_sql = 'WHERE ' . implode(' AND ', $where);
}

$sql = "SELECT b.*, GROUP_CONCAT(d.event_date ORDER BY d.event_date) AS event_dates
        FROM bookings b
        LEFT JOIN booking_dates d ON b.id = d.booking_id";

if ($event_date) {
    $join_where = "d.event_date = ?";
    if ($where_sql) {
        $where_sql .= " AND $join_where";
    } else {
        $where_sql = "WHERE $join_where";
    }
    $params[] = $event_date;
    $types .= 's';
}

$sql .= " $where_sql GROUP BY b.id ORDER BY b.created_at DESC";

$stmt = $conn->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Bookings</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #c6953F;
        color: #300B1C;
        margin: 0;
        padding: 40px 20px;
    }

    h1 {
        text-align: center;
        color: #4b0000;
        margin-bottom: 30px;
    }

    form {
        background: #fff;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        max-width: 1000px;
        margin: auto;
        margin-bottom: 30px;
    }

    form label {
        font-weight: bold;
        margin-right: 10px;
    }

    form input, form select {
        padding: 8px;
        margin: 5px 10px 10px 0;
        border-radius: 6px;
        border: 1px solid #ccc;
    }

    form button, form a {
        padding: 10px 20px;
        background: #4b0000;
        color: #FFD700;
        border: none;
        border-radius: 6px;
        font-weight: bold;
        text-decoration: none;
        margin-right: 10px;
        cursor: pointer;
    }

    form button:hover, form a:hover {
        background: #FFD700;
        color: #300B1C;
    }

    table {
        border-collapse: collapse;
        width: 100%;
        background: #fff;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        border-radius: 12px;
        overflow: hidden;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: center;
    }

    th {
        background: #4b0000;
        color: #FFD700;
    }

    tr:nth-child(even) {
        background: #f9f9f9;
    }

    .status-Pending {
        color: orange;
        font-weight: bold;
    }

    .status-Paid {
        color: green;
        font-weight: bold;
    }

    .status-Confirmed {
        color: #0077cc;
        font-weight: bold;
    }

    .status-Cancelled {
        color: red;
        font-weight: bold;
    }

    .cancel-link {
        color: #4b0000;
        font-weight: bold;
        text-decoration: none;
    }

    .cancel-link:hover {
        color: #FFD700;
    }

    .manage-link {
        display: block;
        text-align: center;
        margin: 20px auto;
        font-weight: bold;
        color: #4b0000;
        text-decoration: none;
    }

    .manage-link:hover {
        color: #FFD700;
    }
</style>
</head>
<body>

<h1>📋 Manage Bookings</h1>

<form method="get">
    <label>Status:</label>
    <select name="status">
        <option value="">All</option>
        <option value="Pending" <?= $status === 'Pending' ? 'selected' : '' ?>>Pending</option>
        <option value="Paid" <?= $status === 'Paid' ? 'selected' : '' ?>>Paid</option>
        <option value="Confirmed" <?= $status === 'Confirmed' ? 'selected' : '' ?>>Confirmed</option>
        <option value="Cancelled" <?= $status === 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
    </select>

    <label>Client Name:</label>
    <input type="text" name="client_name" value="<?= htmlspecialchars($client_name) ?>">

    <label>Event Date:</label>
    <input type="date" name="event_date" value="<?= htmlspecialchars($event_date) ?>">

    <label>Function:</label>
    <input type="text" name="function_type" value="<?= htmlspecialchars($function_type) ?>">

    <label>Venue:</label>
    <input type="text" name="venue" value="<?= htmlspecialchars($venue) ?>">

    <button type="submit">🔍 Filter</button>
    <a href="manage_bookings_list.php">🔄 Reset</a>
</form>


<table>
<thead>
<tr>
    <th>ID</th>
    <th>Client</th>
    <th>Phone</th>
    <th>Function</th>
    <th>Venue</th>
    <th>Decoration</th>
    <th>Event Dates</th>
    <th>Guests</th>
    <th>Price</th>
    <th>Status</th>
    <th>Booked On</th>
    <th>Actions</th>
</tr>
</thead>
<tbody>
<?php while ($booking = $result->fetch_assoc()): ?>
<tr>
    <td><?= $booking['id'] ?></td>
    <td><?= htmlspecialchars($booking['client_name']) ?></td>
    <td><?= htmlspecialchars($booking['phone']) ?></td>
    <td><?= htmlspecialchars($booking['function_type']) ?></td>
    <td><?= htmlspecialchars($booking['venue']) ?></td>
    <td><?= htmlspecialchars($booking['decoration_option']) ?></td>
    <td><?= htmlspecialchars($booking['event_dates']) ?></td>
    <td><?= htmlspecialchars($booking['guests']) ?></td>
    <td>₹ <?= number_format($booking['total_price'], 2) ?></td>
    <td class="status-<?= $booking['status'] ?>"><?= htmlspecialchars($booking['status']) ?></td>
    <td><?= htmlspecialchars($booking['created_at']) ?></td>
    <td>
        <?php if($booking['status'] !== 'Cancelled'): ?>
            <a href="cancel_booking.php?booking_id=<?= $booking['id'] ?>" class="cancel-link" onclick="return confirm('Cancel this booking?')">❌ Cancel</a>
        <?php else: ?>
            <span class="status-Cancelled">Cancelled</span>
        <?php endif; ?>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<a href="manage_bookings.php" class="back-link">⬅ Back</a>

</body>
</html>
