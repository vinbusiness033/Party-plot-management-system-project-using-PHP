<?php
include("../config/db.php");

$booking_id = intval($_GET['booking_id'] ?? 0);
if ($booking_id) {
    // Get booking data
    $stmt = $conn->prepare("SELECT client_name, phone, email, total_price, status FROM bookings WHERE id = ?");
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows) {
        $booking = $result->fetch_assoc();
        $client_name = $booking['client_name'];
        $phone = $booking['phone'];
        $email = $booking['email'];
        $amount = $booking['total_price'];
        $status = $booking['status'];        
    }
    $stmt->close();

    // Record refund if status is paid
    if ($status === 'Paid') {
        $stmt2 = $conn->prepare("INSERT INTO refunds (booking_id, client_name, phone, email, amount, refund_status) VALUES (?, ?, ?, ?, ?, 'Pending')");
        $stmt2->bind_param("isssi", $booking_id, $client_name, $phone, $email, $amount);
        $stmt2->execute();
        $stmt2->close();
    }

    // Update booking status to Cancelled
    $stmt3 = $conn->prepare("UPDATE bookings SET status = 'Cancelled' WHERE id = ?");
    $stmt3->bind_param("i", $booking_id);
    $stmt3->execute();
    $stmt3->close();
}

header("Location: manage_bookings_list.php");
exit();
