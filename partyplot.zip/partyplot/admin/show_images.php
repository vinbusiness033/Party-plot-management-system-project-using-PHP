<?php
include("../config/db.php");
$result = $conn->query("SELECT * FROM gallery WHERE file_type='image'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Gallery - Images</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        .gallery { display: flex; flex-wrap: wrap; gap: 15px; justify-content: center; }
        .gallery img { width: 250px; height: 200px; object-fit: cover; border-radius: 8px; }
    </style>
</head>
<body>
    <h2>🖼 Image Gallery</h2>
    <div class="gallery">
        <?php while($row = $result->fetch_assoc()) { ?>
            <div>
                <img src="../uploads/<?php echo $row['file_path']; ?>" alt="Image">
                <p><?php echo $row['title']; ?></p>
            </div>
        <?php } ?>
    </div>
</body>
</html>
