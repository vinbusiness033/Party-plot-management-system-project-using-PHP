<!DOCTYPE html>
<html>
<head>
    <title>Manage Gallery</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #c6953F;
            color: #300B1C;
            margin: 0;
            padding: 40px 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .container {
            max-width: 600px;
            width: 100%;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            color: #4b0000;
            margin-bottom: 30px;
        }

        .btn {
            display: block;
            width: 97%;
            padding: 14px;
            margin: 12px 0;
            text-align: center;
            background: #4b0000;
            color: #c6953F;
            text-decoration: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            transition: background 0.3s ease, color 0.3s ease;
        }

        .btn:hover {
            background: #c6953F;
            color: #300B1C;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #4b0000;
            color: #c6953F;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>🎨 Manage Gallery</h2>

        <a href="gallery_show.php" class="btn">📂 Show Existing Gallery</a>
        <a href="gallery_update.php" class="btn">✏️ Update Gallery</a>
        <a href="gallery_highlights.php" class="btn">🌟 Manage Highlights</a>

        <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
    </div>
</body>
</html>
