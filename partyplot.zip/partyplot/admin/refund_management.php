<?php
include("../config/db.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $refund_id = intval($_POST['refund_id']);
    $action = $_POST['action'];
    if (in_array($action, ['Processed', 'Rejected'], true)) {
        $update_stmt = $conn->prepare("UPDATE refunds SET refund_status = ? WHERE id = ?");
        $update_stmt->bind_param("si", $action, $refund_id);
        $update_stmt->execute();
        $update_stmt->close();
    }
}

$sql = "SELECT r.*, b.function_type, b.venue, b.status AS booking_status
        FROM refunds r
        JOIN bookings b ON r.booking_id = b.id
        ORDER BY r.created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Refund Management</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #c6953F;
        color: #300B1C;
        margin: 0;
        padding: 40px 20px;
    }

    h1 {
        text-align: center;
        color: #4b0000;
        margin-bottom: 30px;
    }

    table {
        border-collapse: collapse;
        width: 100%;
        background: #fff;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        border-radius: 12px;
        overflow: hidden;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: center;
    }

    th {
        background: #4b0000;
        color: #FFD700;
    }

    tr:nth-child(even) {
        background: #f9f9f9;
    }

    .status-Pending {
        color: orange;
        font-weight: bold;
    }

    .status-Processed {
        color: green;
        font-weight: bold;
    }

    .status-Rejected {
        color: red;
        font-weight: bold;
    }

    button {
        padding: 8px 14px;
        background: #4b0000;
        color: #FFD700;
        border: none;
        border-radius: 6px;
        font-weight: bold;
        cursor: pointer;
        margin: 4px;
    }

    button:hover {
        background: #FFD700;
        color: #300B1C;
    }

    .back-link {
        display: inline-block;
        margin-top: 30px;
        padding: 12px 24px;
        background: #4b0000;
        color: #FFD700;
        text-decoration: none;
        border-radius: 6px;
        font-weight: bold;
        text-align: center;
    }

    .back-link:hover {
        background: #FFD700;
        color: #300B1C;
    }
</style>
</head>
<body>

<h1>💸 Refund Management</h1>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Booking ID</th>
            <th>Client Name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Amount (₹)</th>
            <th>Function</th>
            <th>Venue</th>
            <th>Booking Status</th>
            <th>Refund Status</th>
            <th>Requested On</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['booking_id']) ?></td>
                    <td><?= htmlspecialchars($row['client_name']) ?></td>
                    <td><?= htmlspecialchars($row['phone']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td>₹<?= number_format($row['amount'], 2) ?></td>
                    <td><?= htmlspecialchars($row['function_type']) ?></td>
                    <td><?= htmlspecialchars($row['venue']) ?></td>
                    <td><?= htmlspecialchars($row['booking_status']) ?></td>
                    <td class="status-<?= htmlspecialchars($row['refund_status']) ?>">
                        <?= htmlspecialchars($row['refund_status']) ?>
                    </td>
                    <td><?= htmlspecialchars($row['created_at']) ?></td>
                    <td>
                        <?php if ($row['refund_status'] === 'Pending'): ?>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="refund_id" value="<?= $row['id'] ?>" />
                            <button type="submit" name="action" value="Processed">✔️ Process</button>
                            <button type="submit" name="action" value="Rejected">❌ Reject</button>
                        </form>
                        <?php else: ?>
                            <span style="font-weight:bold;">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="12" style="color:red;">⚠️ No refund requests found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<div style="text-align:center;">
    <a href="manage_bookings.php" class="back-link">⬅ Back</a>
</div>

</body>
</html>
