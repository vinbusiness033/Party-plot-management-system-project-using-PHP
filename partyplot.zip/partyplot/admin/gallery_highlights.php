<?php
include("../config/db.php");

if (isset($_GET['toggle_id'])) {
    $id = intval($_GET['toggle_id']);
    $sql = "UPDATE gallery SET is_highlight = 1 - is_highlight WHERE id = $id";
    $conn->query($sql);
    header("Location: gallery_highlights.php");
    exit;
}

$sql = "SELECT * FROM gallery ORDER BY is_highlight DESC, id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Highlights</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #c6953F;
            color: #300B1C;
            margin: 0;
            padding: 30px;
            text-align: center;
        }

        h2 {
            color: #4b0000;
            margin-bottom: 10px;
        }

        p {
            font-weight: bold;
            margin-bottom: 20px;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 30px;
            padding: 10px 20px;
            background: #4b0000;
            color: #c6953F;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }

        .media-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }

        .media-box {
            border: 1px solid #ccc;
            padding: 15px;
            text-align: center;
            width: 260px;
            border-radius: 10px;
            background: #fff;
            box-shadow: 0 2px 6px rgba(0,0,0,0.2);
        }

        img, video {
            max-width: 100%;
            height: auto;
            border-radius: 6px;
        }

        .btn {
            display: block;
            margin-top: 12px;
            padding: 10px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            transition: background 0.3s ease, color 0.3s ease;
        }

        .highlight {
            background: #ffae00ff;
            color: #300B1C;
        }

        .normal {
            background: #4b0000;
            color: #c6953F;
        }

        .btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

    <h2>🌟 Manage Highlights</h2>
    <p>Select which media should appear in the client-side gallery highlights loop.</p>
    <a href="admin_gallery.php" class="back-link">⬅ Back to Manage Gallery</a>

    <div class="media-container">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="media-box">
                <p><b><?php echo htmlspecialchars($row['function_type']); ?></b></p>
                <?php if (in_array($row['file_type'], ['jpg','heic','jpeg','png','gif'])): ?>
                    <img src="../uploads/<?php echo $row['file_name']; ?>" alt="Image">
                <?php else: ?>
                    <video controls>
                        <source src="../uploads/<?php echo $row['file_name']; ?>" type="video/<?php echo $row['file_type']; ?>">
                    </video>
                <?php endif; ?>

                <?php if ($row['is_highlight'] == 1): ?>
                    <a href="?toggle_id=<?php echo $row['id']; ?>" class="btn highlight">🌟 Highlighted (Click to Remove)</a>
                <?php else: ?>
                    <a href="?toggle_id=<?php echo $row['id']; ?>" class="btn normal">➕ Mark as Highlight</a>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
    </div>

</body>
</html>
