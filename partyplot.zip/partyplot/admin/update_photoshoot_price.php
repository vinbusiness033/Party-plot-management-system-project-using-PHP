<?php
include("../config/db.php");

// Fetch current price
$sql = "SELECT * FROM photoshoot_settings ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);
$current = $result->fetch_assoc();

$base_price = $current['base_price'];
$extra_person_price = $current['extra_person_price'];
$included_persons = $current['included_persons'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_base = $_POST['base_price'];
    $new_extra = $_POST['extra_person_price'];
    $new_included = $_POST['included_persons'];

    $sql_update = "INSERT INTO photoshoot_settings (base_price, extra_person_price, included_persons) 
                   VALUES ('$new_base', '$new_extra', '$new_included')";
    if ($conn->query($sql_update) === TRUE) {
        echo "<script>alert('Photoshoot settings updated successfully!'); window.location.href='update_photoshoot_price.php';</script>";
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Photoshoot Settings</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #c6953F;
            color: #4b0000;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            text-align: center;
            color: #4b0000;
            margin-bottom: 30px;
        }

        .form-box {
            background: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            max-width: 500px;
            width: 100%;
        }

        label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
            color: #4b0000;
        }

        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #4b0000;
            color: #c6953F;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            margin-top: 25px;
            cursor: pointer;
        }

        button:hover {
            background: #2e0000ff;
        }

        .back-link {
            display: inline-block;
            margin-top: 30px;
            padding: 10px 20px;
            background: #300B1C;
            color: #c6953F;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h2>📸 Update Photoshoot Settings</h2>

    <form method="POST" class="form-box">
        <label>Base Price (₹):</label>
        <input type="number" name="base_price" value="<?php echo $base_price; ?>" required>

        <label>Included Persons:</label>
        <input type="number" name="included_persons" value="<?php echo $included_persons; ?>" required>

        <label>Extra Person Price (₹):</label>
        <input type="number" name="extra_person_price" value="<?php echo $extra_person_price; ?>" required>

        <button type="submit">Update Settings</button>
    </form>

    <a href="photoshoot_menu.php" class="back-link">⬅️ Back</a>

</body>
</html>
