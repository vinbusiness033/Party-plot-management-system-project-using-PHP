<!DOCTYPE html>
<html>
<head>
    <title>Update Gallery</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #c6953F;
            color: #300B1C;
            margin: 0;
            padding: 40px 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .container {
            max-width: 500px;
            width: 100%;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            text-align: center;
        }

        h2 {
            color: #4b0000;
            margin-bottom: 30px;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 14px;
            margin: 12px 0;
            background: #4b0000;
            color: #c6953F;
            text-decoration: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            transition: background 0.3s ease, color 0.3s ease;
        }

        .btn:hover {
            background: #2e0a1bff;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #4b0000;
            color: #c6953F;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>✏️ Update Gallery</h2>

        <a href="gallery_upload.php" class="btn">⬆️ Upload Image/Video</a>
        <a href="gallery_delete.php" class="btn">🗑 Delete Image/Video</a>

        <a href="admin_gallery.php" class="back-link">⬅ Back</a>
    </div>
</body>
</html>
