<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0; padding: 0;
            background: #c6953F; /* Dark plum background */
            color: #fff;
        }
        header {
            background: #390000ff; /* Deep burgundy */
            color: #c6953F; /* Solid gold text        #300B1C  #4b0000*/ 
            padding: 15px;
            text-align: center;
            font-size: 17px;
        }
        .container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 30px;
        }
        .card {
            background: #4b0000; /* Warm gold-brown */
            border-radius: 10px;
            border:2px solid gold;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
            padding: 40px 20px;
            text-align: center;
            cursor: pointer;
            transition: background 0.3s ease, color 0.3s ease;
        }
        .card h3 {
            margin: 0;
            color: #c6953F; /* Burgundy text */
        }
        .card:hover {
            background: #2d0000ff; /* Solid gold hover */
            color: #300B1C;
        }
        a {
            text-decoration: none;
        }
        .button-link {
            display: inline-block;
            margin: 20px auto;
            text-align: center;
            padding: 10px 20px;
            background: #300B1C;
            color: #c6953F;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }
        .button-wrapper {
            text-align: center;
        }
    </style>
</head>
<body>

<header>
    <h1>🎛 Admin Dashboard</h1>
</header>

<div class="container">
    
    <a href="register.php">
        <div class="card"><h3>👤 Manage Admins</h3></div>
    </a>

    <a href="photoshoot_menu.php">
        <div class="card"><h3>📸 Manage Photoshoot</h3></div>
    </a>

    <a href="admin_gallery.php">
        <div class="card"><h3>🖼 Manage Gallery</h3></div>
    </a>

    <a href="manage_packages.php">
        <div class="card"><h3>🎁 Manage Packages</h3></div>
    </a>

     <a href="admin_feedback.php">
        <div class="card"><h3>Feedbacks</h3></div>
    </a>

    <a href="manage_bookings.php">
        <div class="card"><h3>📅 Manage Bookings</h3></div>
    </a>

    <a href="admin_contact.php">
        <div class="card"><h3>📞 Manage contact</h3></div>
    </a>

     <a href="admin_about_us.php">
        <div class="card"><h3> Manage About Us</h3></div>
    </a>

   <!--  <a href="inquiries_menu.php">
        <div class="card"><h3>📨 Inquiries</h3></div>
    </a>-->


   <!-- <a href="reports_menu.php">
        <div class="card"><h3>📊 Reports</h3></div>
    </a>-->

    

    <!--<a href="feedbacks_menu.php">
        <div class="card"><h3>💬 Feedbacks</h3></div>
    </a>-->

</div>

<div class="button-wrapper">
    <a href="../public/index.php" class="button-link">⬅️ Logout</a>
</div>

</body>
</html>
