<!DOCTYPE html>
<html>
<head>
    <title>Manage Packages</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background: #f8f8f8;
        }
        .header {
            background: #4b0000;
            color: white;
            padding: 20px;
            text-align: center;
        }
        h2 {
            margin: 0;
            font-size: 28px;
            color: #c6953F;
        }
        .container {
            text-align: center;
            padding: 50px 20px;
        }
        .btn {
            display: inline-block;
            margin: 20px;
            padding: 20px 35px;
            font-size: 20px;
            font-weight: bold;
            text-decoration: none;
            border-radius: 10px;
            border: 2px solid gold;
            transition: 0.3s;
        }
        .btn-price {
            background: #300B1C;
            color: white;
        }
        .btn-details {
            background: #c6953F;
            color: #300B1C;
        }
        .btn:hover {
            background: gold;
            color: #4b0000;
        }
        .back-link {
            display: inline-block;
            margin-top: 30px;
            color: #4b0000;
            text-decoration: none;
            font-weight: bold;
        }
        .back-link:hover {
            color: #c6953F;
        }
    </style>
</head>
<body>

    <div class="header">
        <h2>🎁 Manage Packages</h2>
    </div>

    <div class="container">
        <a href="manage_package_prices.php" class="btn btn-price">💰 Manage Prices</a>
        <a href="manage_package_details.php" class="btn btn-details">🏛 Manage Details</a>
        <br>
        <a href="dashboard.php" class="back-link">⬅ Back to Dashboard</a>
    </div>

</body>
</html>
