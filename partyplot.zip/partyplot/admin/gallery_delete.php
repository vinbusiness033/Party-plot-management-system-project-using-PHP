<?php
include("../config/db.php");

if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    $sql = "SELECT file_name FROM gallery WHERE id = $id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $file = $row['file_name'];
        $filePath = "../uploads/" . $file;
        if (file_exists($filePath)) {
            unlink($filePath);
        }
        $conn->query("DELETE FROM gallery WHERE id = $id");
        echo "<p style='color:green;'>✅ File deleted successfully.</p>";
    }
}

$type = isset($_GET['type']) ? $_GET['type'] : "";
$media = [];

if ($type == "images") {
    $sql = "SELECT * FROM gallery WHERE file_type IN ('jpg','heic','jpeg','png','gif')";
    $media = $conn->query($sql);
} elseif ($type == "videos") {
    $sql = "SELECT * FROM gallery WHERE file_type IN ('mp4','avi','mov')";
    $media = $conn->query($sql);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Gallery</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #c6953F;
            color: #300B1C;
            margin: 0;
            padding: 30px;
            text-align: center;
        }

        h2 {
            color: #4b0000;
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            margin: 10px;
            padding: 10px 18px;
            background: #4b0000;
            color: #c6953F;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: background 0.3s ease, color 0.3s ease;
        }

        .btn:hover {
            background: #250816ff;
        }

        .media-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            margin-top: 30px;
        }

        .media-box {
            border: 1px solid #ccc;
            padding: 15px;
            text-align: center;
            width: 280px;
            border-radius: 10px;
            background: #fff;
            box-shadow: 0 2px 6px rgba(0,0,0,0.2);
        }

        img, video {
            max-width: 100%;
            height: auto;
            border-radius: 6px;
            cursor: pointer;
        }

        .delete-btn {
            display: block;
            margin-top: 12px;
            padding: 10px;
            background: #4b0000;
            color: #FFD700;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }

        .delete-btn:hover {
            background: #FFD700;
            color: #300B1C;
        }

        #imageModal {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.85);
            text-align: center;
            z-index: 1000;
        }

        #imageModal img {
            max-width: 90%;
            max-height: 90%;
            margin-top: 50px;
            border-radius: 8px;
        }

        #imageModal span {
            position: absolute;
            top: 20px;
            right: 40px;
            color: white;
            font-size: 40px;
            cursor: pointer;
        }

        .back-link {
            display: inline-block;
            margin-top: 30px;
            padding: 10px 20px;
            background: #4b0000;
            color: #c6953F;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h2>🗑 Delete Gallery Media</h2>

    <div>
        <a href="?type=images" class="btn">🖼 View Images</a>
        <a href="?type=videos" class="btn">🎥 View Videos</a>
    </div>

    <?php if ($type && $media && $media->num_rows > 0): ?>
        <div class="media-container">
            <?php while ($row = $media->fetch_assoc()): ?>
                <div class="media-box">
                    <p><b><?php echo htmlspecialchars($row['function_type']); ?></b></p>
                    <?php if ($type == "images"): ?>
                        <img src="../uploads/<?php echo $row['file_name']; ?>" 
                             alt="Image" 
                             onclick="openModal('../uploads/<?php echo $row['file_name']; ?>')">
                    <?php else: ?>
                        <video controls>
                            <source src="../uploads/<?php echo $row['file_name']; ?>" type="video/<?php echo $row['file_type']; ?>">
                        </video>
                    <?php endif; ?>
                    <a href="?type=<?php echo $type; ?>&delete_id=<?php echo $row['id']; ?>" class="delete-btn"
                       onclick="return confirm('Are you sure you want to delete this file?')">❌ Delete</a>
                </div>
            <?php endwhile; ?>
        </div>
    <?php elseif ($type): ?>
        <p style="color:red; margin-top:20px;">⚠️ No <?php echo $type; ?> found.</p>
    <?php endif; ?>

    <!-- Modal for image preview -->
    <div id="imageModal">
        <span onclick="closeModal()">&times;</span>
        <img id="modalImg" src="">
    </div>

    <a href="gallery_update.php" class="back-link">⬅ Back</a>

    <script>
        function openModal(src) {
            document.getElementById("imageModal").style.display = "block";
            document.getElementById("modalImg").src = src;
        }
        function closeModal() {
            document.getElementById("imageModal").style.display = "none";
        }
    </script>

</body>
</html>
