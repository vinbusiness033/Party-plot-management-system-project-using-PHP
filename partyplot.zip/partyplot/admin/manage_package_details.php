<?php
include("../config/db.php");

$msg = "";

// ✅ Fetch existing package details (latest record)
$sql = "SELECT * FROM package_details ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);
$package = $result->num_rows > 0 ? $result->fetch_assoc() : null;

// ✅ Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $facilities   = $_POST['facilities'];
    $capacity     = $_POST['capacity'];
    $duration     = $_POST['duration'];
    $services     = $_POST['services'];
    $policies     = $_POST['policies'];
    $cancellation = $_POST['cancellation'];
    $other        = $_POST['other'];

    if ($package) {
        // Update existing record
        $sql = "UPDATE package_details SET 
                    facilities='$facilities',
                    guest_capacity='$capacity',
                    duration='$duration',
                    services='$services',
                    policies='$policies',
                    cancellation_policy='$cancellation',
                    other_details='$other',
                    updated_at=NOW()
                WHERE id=" . $package['id'];
    } else {
        // Insert new record
        $sql = "INSERT INTO package_details 
                (facilities, guest_capacity, duration, services, policies, cancellation_policy, other_details, created_at)
                VALUES ('$facilities', '$capacity', '$duration', '$services', '$policies', '$cancellation', '$other', NOW())";
    }

    if ($conn->query($sql)) {
        $msg = "✅ Package details saved successfully!";
        // Reload updated values
        $result = $conn->query("SELECT * FROM package_details ORDER BY id DESC LIMIT 1");
        $package = $result->fetch_assoc();
    } else {
        $msg = "❌ Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Package Details</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f8f8f8; }
        .header { background: #4b0000; color: white; padding: 20px; text-align: center; }
        h2 { margin: 0; font-size: 28px; color: #c6953F; }
        .container { max-width: 800px; margin: 40px auto; background: white;
            padding: 25px; border-radius: 12px; border: 2px solid #c6953F; }
        label { font-weight: bold; color: #300B1C; display: block; margin: 10px 0 5px; }
        textarea, input { width: 100%; padding: 10px; margin-bottom: 15px;
            border: 1px solid #ccc; border-radius: 5px; }
        button {
            width: 100%; padding: 12px; background: #c6953F; color: #300B1C;
            border: none; border-radius: 6px; font-size: 16px; font-weight: bold; cursor: pointer;
        }
        button:hover { background: gold; color: #4b0000; }
        .msg { text-align: center; margin-bottom: 15px; color: darkgreen; font-weight: bold; }
        .back-link { display: block; text-align: center; margin-top: 20px; color: #4b0000;
            font-weight: bold; text-decoration: none; }
        .back-link:hover { color: #c6953F; }
    </style>
</head>
<body>
    <div class="header"><h2>🏛 Manage Package Details</h2></div>
    <div class="container">
        <?php if ($msg) echo "<p class='msg'>$msg</p>"; ?>
        <form method="post">
            <label>Facilities (comma separated)</label>
            <textarea name="facilities" required><?php echo $package['facilities'] ?? ''; ?></textarea>
            
            <label>Guest Capacity</label>
            <input type="number" name="capacity" required value="<?php echo $package['guest_capacity'] ?? ''; ?>">
            
            <label>Duration (Full day / Half day)</label>
            <input type="text" name="duration" required value="<?php echo $package['duration'] ?? ''; ?>">
            
            <label>Services</label>
            <textarea name="services" required><?php echo $package['services'] ?? ''; ?></textarea>
            
            <label>Party Plot Policies</label>
            <textarea name="policies" required><?php echo $package['policies'] ?? ''; ?></textarea>
            
            <label>Cancellation Policy</label>
            <textarea name="cancellation" required><?php echo $package['cancellation_policy'] ?? ''; ?></textarea>
            
            <label>Other Details</label>
            <textarea name="other"><?php echo $package['other_details'] ?? ''; ?></textarea>
            
            <button type="submit">💾 Save Details</button>
        </form>
        <a href="manage_packages.php" class="back-link">⬅ Back</a>
    </div>
</body>
</html>
