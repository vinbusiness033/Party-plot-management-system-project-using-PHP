<?php
include("../config/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $function = $_POST['function'];
    $files = $_FILES["media"];

    for ($i = 0; $i < count($files["name"]); $i++) {
        if ($files["error"][$i] == 0) {
            $uploadDir = __DIR__ . "/../uploads/";
            $fileName = time() . "_" . basename($files["name"][$i]);
            $targetFilePath = $uploadDir . $fileName;

            $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $allowedTypes = ["jpg","heic","jpeg","png","gif","mp4","avi","mov"];

            if (in_array($fileType, $allowedTypes)) {
                $imageTypes = ["jpg","heic","jpeg","png","gif"];
                $videoTypes = ["mp4","avi","mov"];

                $mediaType = in_array($fileType, $imageTypes) ? "image" :
                             (in_array($fileType, $videoTypes) ? "video" : "other");

                if (move_uploaded_file($files["tmp_name"][$i], $targetFilePath)) {
                    $sql = "INSERT INTO gallery (function_type, media_type, file_name, file_type) 
                            VALUES ('$function', '$mediaType', '$fileName', '$fileType')";
                    if ($conn->query($sql) === TRUE) {
                        echo "<p style='color:green;'>✅ {$files['name'][$i]} uploaded successfully as <b>$mediaType</b>.</p>";
                    } else {
                        echo "<p style='color:red;'>❌ DB Error for {$files['name'][$i]}: " . $conn->error . "</p>";
                    }
                } else {
                    echo "<p style='color:red;'>❌ Failed to upload {$files['name'][$i]}.</p>";
                }
            } else {
                echo "<p style='color:red;'>❌ {$files['name'][$i]} - Invalid file type.</p>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload Gallery</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #c6953F;
            color: #300B1C;
            margin: 0;
            padding: 40px 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            color: #4b0000;
            margin-bottom: 30px;
        }

        .form-box {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            max-width: 500px;
            width: 100%;
        }

        label {
            font-weight: bold;
            color: #4b0000;
            display: block;
            margin-top: 15px;
        }

        select, input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #4b0000;
            color: #c6953F;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            margin-top: 25px;
            cursor: pointer;
        }

        button:hover {
            background: #320b1dff;
        }

        .back-link {
            display: inline-block;
            margin-top: 30px;
            padding: 10px 20px;
            background: #4b0000;
            color: #c6953F;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h2>📤 Upload Image/Video</h2>

    <form method="POST" enctype="multipart/form-data" class="form-box">
        <label>Select Function:</label>
        <select name="function" required>
            <option value="Wedding">Wedding</option>
            <option value="Birthday">Birthday</option>
            <option value="Corporate">Corporate</option>
            <option value="Engagement">Engagement</option>
            <option value="Photoshoot">Photoshoot</option>
            <option value="Rooms">Staying Rooms</option>
            <option value="Other">Other</option>
        </select>

        <label>Select Files:</label>
        <input type="file" name="media[]" multiple required>

        <button type="submit">⬆️ Upload</button>
    </form>

    <a href="gallery_update.php" class="back-link">⬅ Back</a>

</body>
</html>
