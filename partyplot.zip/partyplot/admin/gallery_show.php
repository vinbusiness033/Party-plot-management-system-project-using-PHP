<?php
include("../config/db.php");

$type = isset($_GET['type']) ? $_GET['type'] : "";
$function = isset($_GET['function']) ? $_GET['function'] : "All";

$functions = ["All","Wedding","Birthday","Corporate","Engagement","Photoshoot","Rooms","Other"];
$gallery = [];

if ($type) {
    if ($function == "All") {
        $sql = ($type == "images")
            ? "SELECT * FROM gallery WHERE file_type IN ('jpg','heic','jpeg','png','gif')"
            : "SELECT * FROM gallery WHERE file_type IN ('mp4','avi','mov')";
    } else {
        $sql = ($type == "images")
            ? "SELECT * FROM gallery WHERE function_type='$function' AND file_type IN ('jpg','heic','jpeg','png','gif')"
            : "SELECT * FROM gallery WHERE function_type='$function' AND file_type IN ('mp4','avi','mov')";
    }
    $gallery = $conn->query($sql);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Show Gallery</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #c6953F;
            color: #300B1C;
            margin: 0;
            padding: 30px;
            text-align: center;
        }

        h2 {
            color: #4b0000;
            margin-bottom: 20px;
        }

        h3 {
            color: #4b0000;
            margin-top: 30px;
        }

        .btn {
            display: inline-block;
            margin: 8px;
            padding: 10px 18px;
            background: #4b0000;
            color: #c6953F;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: background 0.3s ease, color 0.3s ease;
        }

        .btn:hover {
            background: #290918ff;
        }

        .media-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            margin-top: 20px;
        }

        .media-box {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
            width: 250px;
            border-radius: 8px;
            background: #fff;
            box-shadow: 0 2px 6px rgba(0,0,0,0.2);
        }

        img, video {
            max-width: 100%;
            height: auto;
            border-radius: 6px;
            cursor: pointer;
        }

        #overlay {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.9);
            justify-content: center;
            align-items: center;
            z-index: 999;
        }

        #overlay img {
            max-width: 90%;
            max-height: 90%;
        }

        #overlay span {
            position: absolute;
            top: 20px;
            right: 40px;
            font-size: 30px;
            color: white;
            cursor: pointer;
        }

        .back-link {
            display: inline-block;
            margin-top: 30px;
            padding: 10px 20px;
            background: #4b0000;
            color: #c6953F;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h2>📂 Show Gallery</h2>

    <!-- Step 1: Choose media type -->
    <?php if (!$type): ?>
        <a href="?type=images&function=All" class="btn">🖼 Show Images</a>
        <a href="?type=videos&function=All" class="btn">🎥 Show Videos</a>
    <?php endif; ?>

    <!-- Step 2: Function filter -->
    <?php if ($type): ?>
        <h3>Select Function (<?php echo ucfirst($type); ?>)</h3>
        <?php foreach ($functions as $f): ?>
            <a href="?type=<?php echo $type; ?>&function=<?php echo $f; ?>"
               class="btn"
               style="<?php echo ($function == $f) ? 'background:#FFD700; color:#300B1C;' : ''; ?>">
                <?php echo $f; ?>
            </a>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Step 3: Show media -->
    <?php if ($type && $gallery): ?>
        <h3><?php echo ucfirst($type); ?> for <span style="color:#FFD700;"><?php echo $function; ?></span></h3>
        <?php if ($gallery->num_rows > 0): ?>
            <div class="media-container">
                <?php while ($row = $gallery->fetch_assoc()): ?>
                    <div class="media-box">
                        <?php if ($type == "images"): ?>
                            <img src="../uploads/<?php echo $row['file_name']; ?>" alt="Image" onclick="openOverlay(this.src)">
                        <?php else: ?>
                            <video controls>
                                <source src="../uploads/<?php echo $row['file_name']; ?>" type="video/<?php echo $row['file_type']; ?>">
                            </video>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p style="color:red;">⚠️ No <?php echo $type; ?> found for <?php echo $function; ?>.</p>
        <?php endif; ?>
    <?php endif; ?>

    <a href="admin_gallery.php" class="back-link">⬅ Back</a>

    <!-- Image Overlay -->
    <div id="overlay" onclick="closeOverlay()">
        <span>&times;</span>
        <img id="overlayImg">
    </div>

    <script>
        function openOverlay(src) {
            document.getElementById("overlayImg").src = src;
            document.getElementById("overlay").style.display = "flex";
        }
        function closeOverlay() {
            document.getElementById("overlay").style.display = "none";
        }
    </script>
</body>
</html>
