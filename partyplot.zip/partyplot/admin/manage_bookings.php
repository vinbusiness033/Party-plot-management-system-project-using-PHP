<?php
session_start();
// Add admin authentication here
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Admin Dashboard - Manage Bookings</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #c6953F;
        color: #300B1C;
        margin: 0;
        padding: 40px 20px;
        display: flex;
        justify-content: center;
    }

    .container {
        max-width: 800px;
        width: 100%;
        background: #fff;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }

    h1 {
        text-align: center;
        color: #4b0000;
        margin-bottom: 30px;
    }

    nav ul {
        list-style: none;
        padding: 0;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        gap: 20px;
        margin-bottom: 30px;
    }

    nav ul li {
        display: inline-block;
    }

    nav ul li a {
        display: inline-block;
        padding: 12px 20px;
        background: #4b0000;
        color: #FFD700;
        border-radius: 8px;
        font-weight: bold;
        text-decoration: none;
        transition: background 0.3s ease, color 0.3s ease;
    }

    nav ul li a:hover {
        background: #FFD700;
        color: #300B1C;
    }

    hr {
        border: none;
        border-top: 1px solid #ccc;
        margin: 30px 0;
    }

    h2 {
        color: #4b0000;
        margin-bottom: 10px;
        text-align: center;
    }

    p {
        text-align: center;
        font-size: 16px;
    }
</style>
</head>
<body>
<div class="container">
    <h1>📋 Manage Bookings</h1>
    <nav>
        <ul>
            <li><a href="manage_bookings_list.php">📋 Manage Bookings</a></li>
            <li><a href="refund_management.php">💸 Check Refund Status</a></li>
            <li><a href="manage_blocked_dates.php">📅 Manage Blocked Dates</a></li>
            <!-- add more admin options here -->
        </ul>
    </nav>

    <hr/>

    <div>
        <h2>Welcome to Booking Management</h2>
        <p>Select from the options above to manage bookings and related settings.</p>
    </div>
     <a href="dashboard.php" class="back-link">⬅️ Back to Dashboard</a>
</div>
</body>
</html>
