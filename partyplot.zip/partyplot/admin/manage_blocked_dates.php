<?php
include("../config/db.php");

$error = '';
$success = '';

// Add blocked date
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $blocked_date = trim($_POST['blocked_date']);
    $reason = trim($_POST['reason']);

    if (!$blocked_date) {
        $error = "Please select a date to block.";
    } else {
        $stmt = $conn->prepare("INSERT INTO blocked_dates (blocked_date, reason) VALUES (?, ?)");
        $stmt->bind_param("ss", $blocked_date, $reason);
        if ($stmt->execute()) {
            $success = "✅ Date blocked successfully.";
        } else {
            $error = "❌ Failed to block date. It might already be blocked.";
        }
        $stmt->close();
    }
}

// Delete blocked date
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM blocked_dates WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_blocked_dates.php");
    exit;
}

$blocked_dates_res = $conn->query("SELECT * FROM blocked_dates ORDER BY blocked_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Manage Blocked Dates</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #c6953F;
        color: #300B1C;
        margin: 0;
        padding: 40px 20px;
    }

    h1 {
        text-align: center;
        color: #4b0000;
        margin-bottom: 30px;
    }

    form {
        background: #fff;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        max-width: 600px;
        margin: auto;
        margin-bottom: 30px;
    }

    form label {
        font-weight: bold;
        margin-right: 10px;
        display: block;
        margin-top: 10px;
    }

    form input[type="date"],
    form input[type="text"] {
        width: 98%;
        padding: 10px;
        margin-top: 5px;
        border-radius: 6px;
        border: 1px solid #ccc;
    }

    form button {
        margin-top: 20px;
        padding: 12px 20px;
        background: #4b0000;
        color: #FFD700;
        border: none;
        border-radius: 6px;
        font-weight: bold;
        cursor: pointer;
        width: 100%;
    }

    form button:hover {
        background: #FFD700;
        color: #300B1C;
    }

    .message {
        text-align: center;
        font-weight: bold;
        margin-bottom: 20px;
    }

    .error {
        color: red;
    }

    .success {
        color: green;
    }

    h2 {
        text-align: center;
        color: #4b0000;
        margin-bottom: 20px;
    }

    table {
        border-collapse: collapse;
        width: 100%;
        background: #fff;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        border-radius: 12px;
        overflow: hidden;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: center;
    }

    th {
        background: #4b0000;
        color: #FFD700;
    }

    tr:nth-child(even) {
        background: #f9f9f9;
    }

    a.remove-link {
        color: #4b0000;
        font-weight: bold;
        text-decoration: none;
    }

    a.remove-link:hover {
        color: #FFD700;
    }

    .back-link {
        display: inline-block;
        margin-top: 30px;
        padding: 12px 24px;
        background: #4b0000;
        color: #FFD700;
        text-decoration: none;
        border-radius: 6px;
        font-weight: bold;
        text-align: center;
    }

    .back-link:hover {
        background: #FFD700;
        color: #300B1C;
    }
</style>
</head>
<body>

<h1>📅 Manage Blocked Dates</h1>

<?php if ($error): ?>
    <div class="message error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
    <div class="message success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="post" action="">
    <label for="blocked_date">Block Date:</label>
    <input type="date" name="blocked_date" id="blocked_date" required>

    <label for="reason">Reason (optional):</label>
    <input type="text" name="reason" id="reason">

    <button type="submit">➕ Add Blocked Date</button>
</form>

<h2>🚫 Blocked Dates</h2>
<table>
    <tr><th>Date</th><th>Reason</th><th>Action</th></tr>
    <?php while ($row = $blocked_dates_res->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['blocked_date']) ?></td>
        <td><?= htmlspecialchars($row['reason']) ?></td>
        <td>
            <a href="?delete_id=<?= $row['id'] ?>" class="remove-link" onclick="return confirm('Confirm remove blocked date?')">❌ Remove</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<div style="text-align:center;">
    <a href="manage_bookings.php" class="back-link">⬅ Back</a>
</div>

</body>
</html>
