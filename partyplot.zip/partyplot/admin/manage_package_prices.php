<?php
include("../config/db.php");

// ✅ Fetch current venue prices
$venue_sql = "SELECT * FROM venue_prices ORDER BY id DESC LIMIT 1";
$venue_result = $conn->query($venue_sql);
$venue = $venue_result->fetch_assoc();

// ✅ Handle Add Function
if (isset($_POST['add_function'])) {
    $newFunction = trim($_POST['new_function']);
    $newPrice = $_POST['new_price'];
    if ($newFunction != "" && $newPrice != "") {
        $conn->query("INSERT INTO decoration_prices (function_type, approx_price) VALUES ('$newFunction', '$newPrice')");
    }
    header("Location: manage_package_prices.php"); exit;
}

// ✅ Handle Delete Function
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM decoration_prices WHERE id=$id");
    header("Location: manage_package_prices.php"); exit;
}

// ✅ Handle Update Prices
if (isset($_POST['update_prices'])) {
    // Update venue prices
    $ground = $_POST['ground_price'];
    $dome = $_POST['dome_price'];
    $room = $_POST['room_price'];

    $conn->query("INSERT INTO venue_prices (ground_price, dome_price, room_price) 
                  VALUES ('$ground', '$dome', '$room')");

    // Update decoration prices
    foreach ($_POST['decoration'] as $id => $price) {
        $conn->query("UPDATE decoration_prices SET approx_price='$price' WHERE id='$id'");
    }

    echo "<script>alert('Packages updated successfully!'); window.location='manage_packages.php';</script>";
    exit;
}

// ✅ Fetch decoration prices
$decoration_sql = "SELECT * FROM decoration_prices";
$decoration_result = $conn->query($decoration_sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Packages - Prices</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f7f3e9; margin: 0; padding: 0; }
        .container {
            max-width: 850px; margin: 30px auto; padding: 25px;
            background: #fff; border: 2px solid #c6953F; border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        h2 { text-align: center; color: #4b0000; margin-bottom: 20px; }
        h3 { color: #c6953F; margin-top: 25px; border-bottom: 2px solid #300B1C; padding-bottom: 5px; }
        label { font-weight: bold; color: #300B1C; }
        input[type=number], input[type=text] {
            width: 100%; padding: 10px; margin: 6px 0 15px;
            border: 1px solid #ccc; border-radius: 6px;
        }
        button {
            width: 100%; padding: 12px; background: #4b0000; color: white;
            font-size: 16px; border: none; border-radius: 8px; cursor: pointer;
        }
        button:hover { background: #300B1C; }
        .delete-btn {
            background: #c6953F; color: #300B1C; font-size: 12px;
            padding: 5px 8px; border-radius: 6px; text-decoration: none;
        }
        .delete-btn:hover { background: red; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h2>🎁 Manage Package Prices</h2>

        <form method="POST">
            <!-- Venue Prices -->
            <h3>🏟 Venue Prices (Fixed)</h3>
            <label>Ground Price (₹):</label>
            <input type="number" name="ground_price" value="<?= $venue['ground_price']; ?>" required>

            <label>Dome Price (₹):</label>
            <input type="number" name="dome_price" value="<?= $venue['dome_price']; ?>" required>

            <label>Room Price (₹):</label>
            <input type="number" name="room_price" value="<?= $venue['room_price']; ?>" required>

            <!-- Decoration Prices -->
            <h3>🎨 Decoration Prices (Approx)</h3>
            <?php while ($row = $decoration_result->fetch_assoc()) { ?>
                <label><?= $row['function_type']; ?> (₹):</label>
                <input type="number" name="decoration[<?= $row['id']; ?>]" value="<?= $row['approx_price']; ?>" required>
                <a href="?delete=<?= $row['id']; ?>" class="delete-btn">❌ Remove</a><br><br>
            <?php } ?>

            <button type="submit" name="update_prices">💾 Update Prices</button>
        </form>

        <!-- Add New Function -->
        <h3>➕ Add New Function</h3>
        <form method="POST">
            <label>Function Name:</label>
            <input type="text" name="new_function" placeholder="e.g. Wedding, Birthday" required>
            <label>Approx Price (₹):</label>
            <input type="number" name="new_price" required>
            <button type="submit" name="add_function">➕ Add Function</button>
        </form>

        <div style="text-align:center; margin-top:15px;">
            <a href="manage_packages.php" class="back-link">⬅ Back</a>
        </div>
    </div>
</body>
</html>
