<?php
include("../config/db.php");
$result = $conn->query("SELECT * FROM gallery WHERE file_type='video'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Gallery - Videos</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        .gallery { display: flex; flex-wrap: wrap; gap: 15px; justify-content: center; }
        video { width: 300px; height: 200px; border-radius: 8px; }
    </style>
</head>
<body>
    <h2>🎥 Video Gallery</h2>
    <div class="gallery">
        <?php while($row = $result->fetch_assoc()) { ?>
            <div>
                <video controls>
                    <source src="../uploads/<?php echo $row['file_path']; ?>" type="video/mp4">
                </video>
                <p><?php echo $row['title']; ?></p>
            </div>
        <?php } ?>
    </div>
</body>
</html>
