<?php
include("../config/db.php");

$selected_year = isset($_GET['year']) ? $_GET['year'] : date('Y');
$selected_month = isset($_GET['month']) ? $_GET['month'] : "";

$years = $conn->query("SELECT DISTINCT YEAR(date) as year FROM photoshoots ORDER BY year DESC");

$sql = "
    SELECT 
        DATE_FORMAT(date, '%Y-%m') AS month,
        COUNT(*) AS total_bookings,
        SUM(total_price) AS total_earnings
    FROM photoshoots
    WHERE payment_status = 'paid'
      AND YEAR(date) = '$selected_year'
";

if ($selected_month != "") {
    $sql .= " AND MONTH(date) = '$selected_month'";
}

$sql .= " GROUP BY DATE_FORMAT(date, '%Y-%m') ORDER BY month DESC";
$result = $conn->query($sql);

$total_sql = "
    SELECT 
        COUNT(*) AS grand_total_bookings,
        SUM(total_price) AS grand_total_earnings
    FROM photoshoots
    WHERE payment_status = 'paid'
      AND YEAR(date) = '$selected_year'
";
if ($selected_month != "") {
    $total_sql .= " AND MONTH(date) = '$selected_month'";
}
$total_result = $conn->query($total_sql);
$totals = $total_result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Photoshoot Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: #c6953F;
            color: #300B1C;
        }

        h2 {
            text-align: center;
            color: #4b0000;
            margin-bottom: 30px;
        }

        form {
            text-align: center;
            margin-bottom: 30px;
        }

        select, button {
            padding: 10px;
            margin: 5px;
            border-radius: 6px;
            border: 1px solid #4b0000;
            font-weight: bold;
            background: #fff;
            color: #4b0000;
        }

        button {
            background: #4b0000;
            color: #c6953F;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background: #FFD700;
            color: #300B1C;
        }

        table {
            width: 90%;
            margin: auto;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }

        th {
            background: #4b0000;
            color: #c6953F;
        }

        tr:nth-child(even) {
            background: #f9f9f9;
        }

        .summary {
            font-weight: bold;
            background: #c6953F;
            color: #300B1C;
        }

        .back-link {
            display: inline-block;
            margin-top: 30px;
            padding: 10px 20px;
            background: #4b0000;
            color: #c6953F;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h2>📊 Monthly Photoshoot Report</h2>

    <!-- Filter Form -->
    <form method="GET">
        <label><b>Year:</b></label>
        <select name="year">
            <?php while($y = $years->fetch_assoc()) { ?>
                <option value="<?php echo $y['year']; ?>" 
                    <?php echo ($y['year'] == $selected_year) ? 'selected' : ''; ?>>
                    <?php echo $y['year']; ?>
                </option>
            <?php } ?>
        </select>

        <label><b>Month:</b></label>
        <select name="month">
            <option value="">All</option>
            <?php for($m=1; $m<=12; $m++) { 
                $monthName = date("F", mktime(0,0,0,$m,1)); ?>
                <option value="<?php echo $m; ?>" 
                    <?php echo ($m == $selected_month) ? 'selected' : ''; ?>>
                    <?php echo $monthName; ?>
                </option>
            <?php } ?>
        </select>

        <button type="submit">🔍 Filter</button>
    </form>

    <!-- Report Table -->
    <table>
        <tr>
            <th>Month</th>
            <th>Total Bookings</th>
            <th>Total Earnings (₹)</th>
        </tr>
        <?php if ($result->num_rows > 0) { 
            while($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['month']; ?></td>
                    <td><?php echo $row['total_bookings']; ?></td>
                    <td>₹<?php echo $row['total_earnings']; ?></td>
                </tr>
        <?php } ?>
            <tr class="summary">
                <td>🔢 TOTAL</td>
                <td><?php echo $totals['grand_total_bookings']; ?></td>
                <td>₹<?php echo $totals['grand_total_earnings']; ?></td>
            </tr>
        <?php } else { ?>
            <tr><td colspan="3" style="color:red;">❌ No data found for selected filter</td></tr>
        <?php } ?>
    </table>

    <div style="text-align:center;">
        <a href="photoshoot_menu.php" class="back-link">⬅️ Back</a>
    </div>

</body>
</html>
