<?php
include("../config/db.php");

// Fetch existing contact info (assumed only 1 row)
$sql = "SELECT * FROM contact_info WHERE id = 1";
$result = $conn->query($sql);
$contact = $result->fetch_assoc();

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = $conn->real_escape_string($_POST['phone']);
    $email = $conn->real_escape_string($_POST['email']);
    $address = $conn->real_escape_string($_POST['address']);

    $updateSql = "UPDATE contact_info SET phone='$phone', email='$email', address='$address' WHERE id = 1";

    if ($conn->query($updateSql) === TRUE) {
        $message = "Contact information updated successfully.";
        // Refresh the displayed data
        $contact['phone'] = $phone;
        $contact['email'] = $email;
        $contact['address'] = $address;
    } else {
        $message = "Error updating contact information: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Update Contact Details</title>
    <style>
        body { font-family: Arial, sans-serif; background: #c6953F; color: #4b0000; padding: 20px; }
        .container { max-width: 600px; margin:auto; background:#4b0000; color:white; padding: 20px; border-radius: 8px; }
        label { display: block; margin-top: 10px; color: #c6953F; font-weight:bold; }
        input[type="text"], input[type="email"], textarea { width:100%; padding:10px; margin-top:5px; border-radius: 4px; border: 1px solid #c6953F; background: #1c1c1c; color: white; }
        textarea { resize: vertical; }
        button { margin-top: 15px; background: #300B1C; color: #f9f1f1; font-weight: bold; padding: 12px 25px; border:none; border-radius: 5px; cursor:pointer; }
        button:hover { background: #4b0000; }
        .message { margin-top: 15px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Update Contact Details</h2>

        <?php if ($message != ""): ?>
            <p class="message"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($contact['phone']); ?>" placeholder="+91 9999999999" required />

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($contact['email']); ?>" placeholder="info@example.com" required />

            <label for="address">Address:</label>
            <textarea id="address" name="address" rows="4" required><?php echo htmlspecialchars($contact['address']); ?></textarea>

            <button type="submit">Update Details</button>
            <a href="dashboard.php" class="back-link">⬅ Back</a>
        </form>
    </div>
</body>
</html>
