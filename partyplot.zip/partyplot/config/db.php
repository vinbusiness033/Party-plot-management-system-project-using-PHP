<?php
// Database connection settings
$host = "localhost";      // MySQL host
$user = "root";           // default XAMPP username
$pass = "";               // default XAMPP password is empty
$dbname = "partyplot_db"; // your database name

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optional: set character encoding
$conn->set_charset("utf8");

// Debug message (can remove later)
# echo "Database connected successfully!";
?>
