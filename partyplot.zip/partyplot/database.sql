-- Create Database
CREATE DATABASE IF NOT EXISTS partyplot_db;
USE partyplot_db;

-- =========================
-- 1. Users Table
-- =========================
CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','customer') DEFAULT 'customer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- 2. Bookings Table
-- =========================
CREATE TABLE bookings (
  booking_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  phone VARCHAR(15) NOT NULL,
  event_type VARCHAR(50) NOT NULL,
  requirements VARCHAR(100) NOT NULL, -- ground, dom, rooms, etc.
  event_date DATE NOT NULL,
  guests INT,
  price DECIMAL(10,2) NOT NULL,
  status ENUM('pending','approved','rejected') DEFAULT 'pending',
  payment_status ENUM('unpaid','advance_paid','paid') DEFAULT 'unpaid',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- =========================
-- 3. Photoshoots Table
-- =========================
CREATE TABLE photoshoots (
  ps_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  phone INT(10) NOT NULL,
  user_id INT NULL,
  persons INT NOT NULL,
  date DATE NOT NULL,
  total_price DECIMAL(10,2) NOT NULL,
  payment_status ENUM('unpaid','paid') DEFAULT 'unpaid',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- =========================
-- 4. Packages Table
-- =========================
CREATE TABLE packages (
  package_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- 5. Gallery Table
-- =========================
CREATE TABLE gallery (
  media_id INT AUTO_INCREMENT PRIMARY KEY,
  type ENUM('image','video') NOT NULL,
  function_type VARCHAR(50) NOT NULL, -- Wedding, Birthday, etc.
  file_path VARCHAR(255) NOT NULL,    -- uploads/gallery/file.jpg
  caption VARCHAR(100),
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- 6. Inquiries Table
-- =========================
CREATE TABLE inquiries (
  inquiry_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- 7. Feedbacks Table
-- =========================
CREATE TABLE feedbacks (
  feedback_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  rating INT CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- =========================
-- 8. Availability Table
-- =========================
CREATE TABLE availability (
  id INT AUTO_INCREMENT PRIMARY KEY,
  date DATE NOT NULL,
  reason VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- Insert Default Admin User
-- =========================
INSERT INTO users (username, email, password, role) 
VALUES ('admin', 'admin@partyplot.com', MD5('admin123'), 'admin');
